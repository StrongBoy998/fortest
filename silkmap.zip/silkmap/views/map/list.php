<?php
use yii\helpers\Url;
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
<link rel="stylesheet" href="/statics/css/list.css">
<script type="text/javascript" src="/statics/js/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/script.js"></script>
</head>

<body onload="iFrameHeight()">

<iframe src="/statics/html/list_box.php" frameborder="no" width="100%" name="iframepage" id="mainiframe" marginheight="0" marginwidth="0" scrolling="no"></iframe>

<div class="top_left">
    <a href="<?= Url::to(['findicatordata/map']) ?>" name="list"><span>&lt;</span>&nbsp;返回地图</a>
</div>
<div class="top_right">
    <div class="now">
        <p>当前：<span class="countrys">新西兰、叙利亚、泰国、伊朗、巴基斯坦、菲律宾、新加坡、越南、埃及、波兰、土耳其</span></p>|
        <font class="date_idInfo">2006</font>
        <div class="detail">
            <ul>
                <li>
                    <span>国家：</span>
                    <font class="countrys">
                        新西兰、叙利亚、泰国、伊朗、巴基斯坦、菲律宾、新加坡、越南、埃及、波兰、土耳其
                    </font>
                    <div class="clear"></div>
                </li>
                <li>
                    <span>时间：</span>
                    <font class="date_idInfo">
                      2005
                    </font>
                    <div class="clear"></div>
                </li>
            </ul>
        </div>

    </div>
    <div id="choose">
        <span>&gt;&gt;</span>
        <p>筛选</p>
    </div>
    <div class="clear"></div>
</div>

<div id="alert">
    <button id="close">
        <img src="/statics/images/close.png" alt="关闭">
    </button>
    <div class="alert_box">
        <div class="checkbox">
            <p>国家：</p>
            <form action="">

                <?php foreach ($areadata as $k=>$v): ?>
                    <?php echo '<img src="/statics/images/alert_bg.png">'.$k.'<br />'; ?>
                    <?php foreach ($v as $m=>$n): ?>
                        <?php echo '<label><input name="country" type="checkbox" value="'.$n.'" />'.$m.'<span></span></label>'; ?>
                    <?php endforeach; ?>
                    <div class="clear"></div>
                    <br />
                <?php endforeach; ?>
            </form>
        </div>
        <div class="checkbox">
            <p>时间：</p>
            <form action="" method="" class="time">
                <label class="check_checked"><input name="time" type="radio" value="所有年份" />所有年份</label>
                <label><input name="time" type="radio" value="2016" />2016</label>
                <label><input name="time" type="radio" value="2015" />2015</label>
                <label><input name="time" type="radio" value="2014" />2014</label>
                <label><input name="time" type="radio" value="2013" />2013</label>
                <label><input name="time" type="radio" value="2012" />2012</label>
                <label><input name="time" type="radio" value="2011" />2011</label>
                <label><input name="time" type="radio" value="2010" />2010</label>
                <label><input name="time" type="radio" value="2009" />2009</label>
                <label><input name="time" type="radio" value="2008" />2008</label>
                <label><input name="time" type="radio" value="2007" />2007</label>
                <label><input name="time" type="radio" value="2006" />2006</label>
                <label><input name="time" type="radio" value="2005" />2005</label>
                <label><input name="time" type="radio" value="2004" />2004</label>
                <label><input name="time" type="radio" value="2003" />2003</label>
                <label><input name="time" type="radio" value="2002" />2002</label>
                <label><input name="time" type="radio" value="2001" />2001</label>
                <label><input name="time" type="radio" value="2000" />2000</label>
                <label><input name="time" type="radio" value="1999" />1999</label>
                <label><input name="time" type="radio" value="1998" />1998</label>
                <label><input name="time" type="radio" value="1997" />1997</label>
                <label><input name="time" type="radio" value="1996" />1996</label>
                </br>
                </br>
                <span style="font-size: 14px;color: #CCCCCC;">选择所有年份--->折线图 </br>选择单一年份--->柱状图</span>
                <div class="clear"></div>
            </form>
        </div>
        <div class="checked">
            <p style="margin-top: -20px">已选择：</p>
            <h6>国家：</h6>
            <div class="checked_box" id="s1">
                <div class="clear"></div>
            </div>
        </div>
        <div class="but">
            <button id="reset">重置</button>
            <button id="confirm">确定</button>
        </div>
        <p id="indc_id" hidden >@1DV</p>
    </div>
</div>
</body>
</html>

<script src="/statics/js/echarts.min.js"></script>
<script type="text/javascript" src="/statics/js/graph.js"></script>
<script type="text/javascript" src="/statics/js/filtrate.js"></script>


<script>

        function iFrameHeight(){
            var ifm= document.getElementById("mainiframe");
            ifm.height=document.documentElement.clientHeight;
        }
        window.onresize=function(){
            iFrameHeight();
        }

</script>

