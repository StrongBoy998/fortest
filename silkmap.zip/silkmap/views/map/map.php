<?php
use yii\helpers\Url;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/statics/css/map.css">
    <script type="text/javascript" src="/statics/js/jquery.min.js"></script>
    <script type="text/javascript" src="/statics/js/script.js"></script>
    <title>Document</title>
</head>
<body>
<div class="top">
    <h1>数据地图</h1>
    <div class="top_left">
        <a href="<?= Url::to(['findicatordata/index']) ?>" name="list">进入图表&nbsp;<span>&gt;</span></a>
    </div>
    <div class="top_right">
        <div class="now" id="tooltip">
            当前：GDP | 2005年
        </div>
        <div id="choose">
            <span>&gt;&gt;</span>
            <p>选择指数</p>
        </div>
        <div class="clear"></div>
    </div>
</div>

<div class="content">
    <div id="silkmap" style="width: 100%;height:100%" ></div>
</div>

<div id="alert">
    <button id="close">
        <img src="/statics/images/close.png" alt="关闭">
    </button>
    <div class="alert_box">
        <div class="checkbox">
            <p>指数：</p>
            <br>
            <form action="" id="navmap">
                <?php foreach ($inddata as $k=>$v): ?>

                    <?php echo '<p class="menu_head">'.$k.'<br /></p><div style="display:none" class="menu_body" >'; ?>
                    <?php foreach ($v as $m=>$n): ?>
                        <?php echo ' <label><input name="country" type="radio" value="'.$n.'" />'.$m.'</label>'; ?>
                    <?php endforeach; ?>
                <div class="clear"></div>
        </div>
        <br />
                <?php endforeach; ?>

            </form>
        </div>
        <div class="checkbox">
            <p>时间：</p><br>
            <form action="" method="" class="time">
                <label><input name="time" type="radio" value="2016" />2016</label>
                <label><input name="time" type="radio" value="2015" />2015</label>
                <label><input name="time" type="radio" value="2014" />2014</label>
                <label><input name="time" type="radio" value="2013" />2013</label>
                <label><input name="time" type="radio" value="2012" />2012</label>
                <label><input name="time" type="radio" value="2011" />2011</label>
                <label><input name="time" type="radio" value="2010" />2010</label>
                <label><input name="time" type="radio" value="2009" />2009</label>
                <label><input name="time" type="radio" value="2008" />2008</label>
                <label><input name="time" type="radio" value="2007" />2007</label>
                <label><input name="time" type="radio" value="2006" />2006</label>
                <label><input name="time" type="radio" value="2005" />2005</label>
                <label><input name="time" type="radio" value="2004" />2004</label>
                <label><input name="time" type="radio" value="2003" />2003</label>
                <label><input name="time" type="radio" value="2002" />2002</label>
                <label><input name="time" type="radio" value="2001" />2001</label>
                <label><input name="time" type="radio" value="2000" />2000</label>
                <label><input name="time" type="radio" value="1999" />1999</label>
                <label><input name="time" type="radio" value="1998" />1998</label>
                <label><input name="time" type="radio" value="1997" />1997</label>
                <label><input name="time" type="radio" value="1996" />1996</label>
                <div class="clear"></div>
            </form>
        </div>

        <div class="but">
            <button id="confirm">确定</button>
        </div>

    </div>
</div>
</body>
</html>



<script src="/statics/js/echarts.min.js"></script>
<script src="/statics/js/world.js"></script>
<script src="/statics/js/map_init.js"></script>

