<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

</head>
<body>

<div id="main" style="width: 1200px;height:800px;" ></div>


</body>
</html>

<!-- 最新版本的 Bootstrap 核心 CSS 文件 -->
<!--<link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">-->

<!-- 可选的 Bootstrap 主题文件（一般不用引入） -->
<!--<link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<!--<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>-->

<!--<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.js" type="text/javascript"></script>-->

<!--<script>-->
<!--$("#but").click(function () {-->
<!--    var indc_id = '@1DV';-->
<!--    $.get('/findicatordata/getdata1',{"indc_id":indc_id},function (data) {-->
<!--        var datas = JSON.parse(data);-->
<!--        for(var i in datas) {//不使用过滤-->
<!--            var str = '<tr> <td>'+i+'</td> <td>'+datas[i][2010]+'</td> <td>'+datas[i][2011]+'</td> <td>'+datas[i][2006]+'</td> <td>'+datas[i][2005]+'</td> <td>'+datas[i][2004]+'</td>  <td>'+datas[i][2003]+'</td>  <td>'+datas[i][2002]+'</td>  <td>'+datas[i][2001]+'</td></tr>';-->
<!--            $("#s1").append(str)-->
<!--        }-->
<!--    })-->
<!--})-->
<!--</script>-->
<script src="/js/jquery.min.js"></script>
<script src="/js/echarts.min.js"></script>
<script src="/js/world.js"></script>
    <script src="/js/esl.js"></script>
<script src="/js/init4.js"></script>
