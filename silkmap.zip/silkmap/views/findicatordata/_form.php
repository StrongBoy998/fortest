<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Findicatordata */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="findicatordata-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'date_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'area_code_lvl_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'indc_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'indc_value')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'load_unit_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'load_unit_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'indc_source_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'indc_type_id')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'is_year')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
