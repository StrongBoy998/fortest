<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\FindicatordataSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Findicatordatas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="findicatordata-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Findicatordata', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'date_id',
            'area_code_lvl_id',
            'indc_id',
            'indc_value',
             'load_unit_id',
             'load_unit_name',
             'indc_source_id',
             'indc_type_id',
             'is_year',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
