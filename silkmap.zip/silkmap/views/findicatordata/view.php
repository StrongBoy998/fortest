<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Findicatordata */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Findicatordatas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="findicatordata-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'date_id',
            'area_code_lvl_id',
            'indc_id',
            'indc_value',
            'load_unit_id',
            'load_unit_name',
            'indc_source_id',
            'indc_type_id',
            'is_year',
        ],
    ]) ?>

</div>
