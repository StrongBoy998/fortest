<?php

namespace app\controllers;

use Yii;
use app\models\Findicatordata;
use app\models\DateIndicator;
use app\models\DArea1;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\DArea;
use PHPExcel;
/**
 * FindicatordataController implements the CRUD actions for Findicatordata model.
 */
class FindicatordataController extends Controller
{

    //导出数据
    public function actionExport()
    {

        $request = Yii::$app->request;
        $indc_id = $request->get("indc_id");//指标维度
        $tooltip  = DateIndicator::find()->where(['indc_id'=>$indc_id])->asArray()->one();
        //设置php超时时间
        ini_set("max_execution_time", "3600");
        ini_set('memory_limit', '512M');
        $start = strtotime(Yii::$app->request->post('date')[0]);
        $end = strtotime(Yii::$app->request->post('date')[1]);

        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', $tooltip['indc_id_name'])
            ->setCellValue('B1', "单位 ".$tooltip['load_unit_name'])
            ->setCellValue('C1', "来源 ".$tooltip['indc_source'])
            ->setCellValue('A2', "国家/时间")
            ->setCellValue('B2', "2016")
            ->setCellValue('C2', "2015")
            ->setCellValue('D2', "2014")
            ->setCellValue('E2', "2013")
            ->setCellValue('F2', "2012")
            ->setCellValue('G2', "2011")
            ->setCellValue('H2', "2010")
            ->setCellValue('I2', "2009")
            ->setCellValue('J2', "2008")
            ->setCellValue('K2', "2007")
            ->setCellValue('L2', "2006")
            ->setCellValue('M2', "2005")
            ->setCellValue('N2', "2004")
            ->setCellValue('O2', "2003")
            ->setCellValue('P2', "2002")
            ->setCellValue('Q2', "2001")
            ->setCellValue('R2', "2000")
            ->setCellValue('S2', "1999")
            ->setCellValue('T2', "1998")
            ->setCellValue('U2', "1997")
            ->setCellValue('V2', "1996");
        //从从数据库查出数据

        $indicators = FIndicatorData::find()
            ->select(['area_code_lvl_id', 'date_id', 'indc_value'])
            ->where(["indc_id" => $indc_id])
            ->andWhere(['BETWEEN', 'date_id', '1996', '2016'])
            ->asArray()
            ->all();
        $arrSort = [];
        $area_names = DArea::find()->select(["area_code_lvl_id",'area_name'])->asArray()->all();
        $area = [];
        foreach ($area_names as $k =>$v){
            $area[$v["area_code_lvl_id"]] = $v["area_name"];
        }

        foreach ($indicators as $uniqid => $row) { //0 ->第一个数组
            //遍历一维数组里面值
            foreach ($row as $key => $value) {//
                if ($key == 'area_code_lvl_id') {
                    if(!isset($area[$value])) continue;
                    $arrSort[$area[$value]][$indicators[$uniqid]['date_id']] =
                        $indicators[$uniqid]['indc_value'];
                }
            }
        }
//        if(array_key_exists("中    国", $arrSort)){
//            $cn = $arrSort["中    国"];
//            unset($arrSort["中    国"]);
//            $arrSort["中    国"] = $cn;
//            $arrSort = array_reverse( $arrSort);
//        };

        $i = 3;
        foreach ($arrSort as $k=>$v) {
            $objectPHPExcel->setActiveSheetIndex(0)
                ->setCellValue("A$i", $k);

                $objectPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue("B$i", array_key_exists('2016',$v)?$v['2016']:"")
                    ->setCellValue("C$i", array_key_exists('2015',$v)?$v["2015"]:"")
                    ->setCellValue("D$i", array_key_exists("2014",$v)?$v["2014"]:"")
                    ->setCellValue("E$i", array_key_exists("2013",$v)?$v["2013"]:"")
                    ->setCellValue("F$i", array_key_exists("2012",$v)?$v["2012"]:"")
                    ->setCellValue("G$i", array_key_exists("2011",$v)?$v["2011"]:"")
                    ->setCellValue("H$i", array_key_exists("2010",$v)?$v["2010"]:"")
                    ->setCellValue("I$i", array_key_exists("2009",$v)?$v["2009"]:"")
                    ->setCellValue("J$i", array_key_exists("2008",$v)?$v["2008"]:"")
                    ->setCellValue("K$i", array_key_exists("2007",$v)?$v["2007"]:"")
                    ->setCellValue("L$i", array_key_exists("2006",$v)?$v["2006"]:"")
                    ->setCellValue("M$i", array_key_exists("2005",$v)?$v["2005"]:"")
                    ->setCellValue("N$i", array_key_exists("2004",$v)?$v["2004"]:"")
                    ->setCellValue("O$i", array_key_exists("2003",$v)?$v["2003"]:"")
                    ->setCellValue("P$i", array_key_exists("2002",$v)?$v["2002"]:"")
                    ->setCellValue("Q$i", array_key_exists("2001",$v)?$v["2001"]:"")
                    ->setCellValue("R$i", array_key_exists("2000",$v)?$v["2000"]:"")
                    ->setCellValue("S$i", array_key_exists("1999",$v)?$v["1999"]:"")
                    ->setCellValue("T$i", array_key_exists("1998",$v)?$v["1998"]:"")
                    ->setCellValue("U$i", array_key_exists("1997",$v)?$v["1997"]:"")
                    ->setCellValue("V$i", array_key_exists("1996",$v)?$v["1996"]:"");


            $i++;
        }

        //防止乱码
        ob_end_clean();
        ob_start();

        header('Content-Type : application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename="' . '导出数据-' . date("Y年m月d日 H时i分") . '.xls"');
        $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
        $objWriter->save('exportData/Data.xls');
        return  'exportData/Data.xls';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }


    /**
     * Lists all Findicatordata models.
     * @return mixed
     */


    //数据列表
    public function actionGetdata1()
    {
        $request = Yii::$app->request;
        $indc_id = $request->get("indc_id");//指标维度
        $indicators = FIndicatorData::find()
            ->select(['area_code_lvl_id', 'date_id', 'indc_value'])
            ->where(["indc_id" => $indc_id])
            ->andWhere(['BETWEEN', 'date_id', '1996', '2016'])
            ->asArray()
            ->all();
            $arrSort = [];
            $area_names = DArea::find()->select(["area_code_lvl_id",'area_name'])->asArray()->all();
            $area = [];
            foreach ($area_names as $k =>$v){
                $area[$v["area_code_lvl_id"]] = $v["area_name"];
            }

        foreach ($indicators as $uniqid => $row) { //0 ->第一个数组
            //遍历一维数组里面值
            foreach ($row as $key => $value) {//
                if ($key == 'area_code_lvl_id') {
                    if(!isset($area[$value])) continue;
                    $arrSort[$area[$value]][$indicators[$uniqid]['date_id']] = $indicators[$uniqid]['indc_value'];
                }
            }
        }
//        if(array_key_exists("中    国", $arrSort)){
//            $cn = $arrSort["中    国"];
//            unset($arrSort["中    国"]);
//            $arrSort["中    国"] = $cn;
//            $arrSort = array_reverse( $arrSort);
//        };
        $tooltip  = DateIndicator::find()->where(['indc_id'=>$indc_id])->asArray()->one();
        return json_encode(['data'=>$arrSort,"tooltip"=>$tooltip]);
    }

    //数据地图
    public function actionGetdata3()
    {
        $request = Yii::$app->request;
        $indc_id = $request->get("indc_id");//指标维度
        $date_id = $request->get("date_id");//指标维度

        $indicators = FIndicatorData::find()
            ->select(['area_code_lvl_id', 'date_id', 'indc_value'])
            ->where(["date_id" => $date_id])
            ->andWhere(['indc_id'=>$indc_id])
            ->asArray()
            ->all();
        $arrSort = [];
        foreach ($indicators as $uniqid => $row) { //0 ->第一个数组
            //遍历一维数组里面值
            foreach ($row as $key => $value) {//
                if ($key == 'area_code_lvl_id') {
                    $arrSort[$value] = $indicators[$uniqid]['indc_value'];
                }
            }
        }
        $newdata = [];
        foreach ($arrSort as $k =>$v){
            $d_area = DArea::find()->select('area_name')->where(array("area_code_lvl_id" => $k))->asArray()->one();
            if(!empty($d_area)){
//                if($d_area['area_name']=="世界"){continue;};
                $newdata[$d_area['area_name']]=$v;
            }else{
                $newdata[$k]=$v;
            }
        }
        $tooltip  = DateIndicator::find()->where(['indc_id'=>$indc_id])->asArray()->one();
        return json_encode(['data'=>$newdata,"tooltip"=>$tooltip]);

    }

    //柱状图
    public function actionGetdata5()
    {
        $request = Yii::$app->request;
        $indc_id = $request->get("indc_id");//指标维度
        $date_id = $request->get("date_id");//指标维度
        $area_code_lvl_id = $request->get("area_code_lvl_id");//指标维度
        $indicators = FIndicatorData::find()
            ->select(['area_code_lvl_id', 'date_id', 'indc_value'])
            ->where(["area_code_lvl_id" => $area_code_lvl_id])
            ->andWhere(['indc_id'=>$indc_id])
            ->andWhere(['date_id'=>$date_id])
            ->asArray()
            ->all();
        $arrSort = [];
        $area_names = DArea::find()->select(["area_code_lvl_id",'area_name'])->asArray()->all();
        $area = [];
        foreach ($area_names as $k =>$v){
            $area[$v["area_code_lvl_id"]] = $v["area_name"];
        }

        foreach ($indicators as $uniqid => $row) { //0 ->第一个数组
            //遍历一维数组里面值
            foreach ($row as $key => $value) {//
                if ($key == 'date_id') {
                    $arrSort[$area[$indicators[$uniqid]['area_code_lvl_id']]] = $indicators[$uniqid]['indc_value'];
                }
            }
        }

        //如果数组里面有中国  就将中国这一行提前
//        if(array_key_exists("中    国", $arrSort)){
//                  $cn = $arrSort["中    国"];
//                  unset($arrSort["中    国"]);
//                  $arrSort["中    国"] = $cn;
//                  $arrSort = array_reverse( $arrSort);
//        };
         $tooltip  = DateIndicator::find()->where(['indc_id'=>$indc_id])->asArray()->one();
        return json_encode(['data'=>$arrSort,"tooltip"=>$tooltip]);
    }

    //折线图
    public function actionGetdata6()
    {
        $request = Yii::$app->request;
        $indc_id = $request->get("indc_id");//指标维度

        $area_code_lvl_id = $request->get("area_code_lvl_id");//指标维度
        $indicators = FIndicatorData::find()
            ->select(['area_code_lvl_id', 'date_id', 'indc_value'])
            ->where(["area_code_lvl_id" => $area_code_lvl_id])
            ->andWhere(['BETWEEN', 'date_id', '1996', '2016'])
            ->andwhere(["indc_id" => $indc_id])
            ->asArray()
            ->all();
        $arrSort = [];
        $area_names = DArea::find()->select(["area_code_lvl_id",'area_name'])->asArray()->all();
        $area = [];
        foreach ($area_names as $k =>$v){
            $area[$v["area_code_lvl_id"]] = $v["area_name"];
        }

        foreach ($indicators as $uniqid => $row) { //0 ->第一个数组
            //遍历一维数组里面值
            foreach ($row as $key => $value) {//
                if ($key == 'area_code_lvl_id') {
                    $arrSort[$area[$value]][$indicators[$uniqid]['date_id']] = $indicators[$uniqid]['indc_value'];
                }
            }
        }

        $newarrSort =[];
        foreach ($arrSort as $k=>$arr){
            ksort($arr);
            $newarrSort[$k]=$arr;
        }
        $tooltip  = DateIndicator::find()->where(['indc_id'=>$indc_id])->asArray()->one();
        return json_encode(['data'=>$newarrSort,"tooltip"=>$tooltip]);
    }

    //地图界面
    public function actionMap(){
        #动态的指标
        $datainds = DateIndicator::find()->asArray()->all();
        $inddata = [];
        foreach ($datainds as $m=>$n){
            foreach ($n as $k=>$v){
                if($k == 'parent_indc_name'){
                    $inddata[$v][$datainds[$m]['indc_id_name']] =$datainds[$m]['indc_id'] ;
                }
            }
        }
        $this->layout = false;
        return $this->render('/map/map', ['inddata'=>$inddata
        ]);
    }

    //index
    public function actionIndex(){
        #动态国家
        $areas = DArea::find()->asArray()->all();
        $areadata = [];
        foreach ($areas as $m=>$n){
            foreach ($n as $k=>$v){
              if($k == 'parent_area'){
                  $areadata[$v][$areas[$m]['area_name']] =$areas[$m]['area_code_lvl_id'];
              }
            }
        }

        $this->layout = false;
        $a =123;
        return $this->render('/map/list', ['areadata'=>$areadata
        ,'a'=>$a]);
    }

    public function actionGetIndic(){
        #动态的指标
        $datainds = DateIndicator::find()->asArray()->all();
        $inddata = [];
        foreach ($datainds as $m=>$n){
            foreach ($n as $k=>$v){
                if($k == 'parent_indc_name'){
                    $inddata[$v][$datainds[$m]['indc_id_name']] =$datainds[$m]['indc_id'] ;
                }
            }
        }
        return json_encode($inddata);
    }

    /**
     * Displays a single Findicatordata model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Findicatordata model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Findicatordata();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Findicatordata model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }
    /**
     * Deletes an existing Findicatordata model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Findicatordata model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Findicatordata the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Findicatordata::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
