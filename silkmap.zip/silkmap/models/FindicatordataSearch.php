<?php

namespace app\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Findicatordata;

/**
 * FindicatordataSearch represents the model behind the search form about `app\models\Findicatordata`.
 */
class FindicatordataSearch extends Findicatordata
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'is_year'], 'integer'],
            [['date_id', 'area_code_lvl_id', 'indc_id', 'load_unit_id', 'load_unit_name', 'indc_source_id', 'indc_type_id'], 'safe'],
            [['indc_value'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Findicatordata::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'indc_value' => $this->indc_value,
            'is_year' => $this->is_year,
        ]);

        $query->andFilterWhere(['like', 'date_id', $this->date_id])
            ->andFilterWhere(['like', 'area_code_lvl_id', $this->area_code_lvl_id])
            ->andFilterWhere(['like', 'indc_id', $this->indc_id])
            ->andFilterWhere(['like', 'load_unit_id', $this->load_unit_id])
            ->andFilterWhere(['like', 'load_unit_name', $this->load_unit_name])
            ->andFilterWhere(['like', 'indc_source_id', $this->indc_source_id])
            ->andFilterWhere(['like', 'indc_type_id', $this->indc_type_id]);

        return $dataProvider;
    }
}
