<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "date_indicator".
 *
 * @property integer $id
 * @property string $indc_id
 * @property string $indc_id_name
 * @property string $load_unit_name
 * @property string $indc_source
 */
class DateIndicator extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'date_indicator';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['indc_id', 'indc_source'], 'string', 'max' => 20],
            [['indc_id_name', 'load_unit_name'], 'string', 'max' => 50],
        ];
    }



    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'indc_id' => 'Date ID',
            'indc_id_name' => 'Date Id Name',
            'load_unit_name' => 'Load Unit Name',
            'indc_source' => 'Indc Source',
        ];
    }
}
