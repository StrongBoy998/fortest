<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "f_indicator_data".
 *
 * @property string $id
 * @property string $date_id
 * @property string $area_code_lvl_id
 * @property string $indc_id
 * @property string $indc_value
 * @property string $load_unit_id
 * @property string $load_unit_name
 * @property string $indc_source_id
 * @property string $indc_type_id
 * @property integer $is_year
 */
class FIndicatorData extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'f_indicator_data';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['date_id', 'area_code_lvl_id', 'indc_id'], 'required'],
            [['indc_value'], 'number'],
            [['is_year'], 'integer'],
            [['date_id'], 'string', 'max' => 10],
            [['area_code_lvl_id', 'indc_id'], 'string', 'max' => 50],
            [['load_unit_id', 'indc_source_id', 'indc_type_id'], 'string', 'max' => 20],
            [['load_unit_name'], 'string', 'max' => 100],
            [['date_id', 'area_code_lvl_id', 'indc_id'], 'unique', 'targetAttribute' => ['date_id', 'area_code_lvl_id', 'indc_id'], 'message' => 'The combination of Date ID, Area Code Lvl ID and Indc ID has already been taken.'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'date_id' => '时间维度',
            'area_code_lvl_id' => '地域维度主键',
            'indc_id' => '指标维度主键',
            'indc_value' => '指标值',
            'load_unit_id' => 'Load Unit ID',
            'load_unit_name' => '单位',
            'indc_source_id' => 'Indc Source ID',
            'indc_type_id' => 'Indc Type ID',
            'is_year' => 'Is Year',
        ];
    }
}
