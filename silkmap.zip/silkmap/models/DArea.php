<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "d_area".
 *
 * @property string $area_code_lvl_id
 * @property string $area_code
 * @property string $area_id
 * @property string $area_name
 * @property string $area_name_eng
 * @property integer $area_type
 * @property string $parent_area_code
 * @property integer $tag_data
 */
class DArea extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'd_area';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['area_code_lvl_id'], 'required'],
            [['area_type', 'tag_data'], 'integer'],
            [['area_code_lvl_id', 'area_code', 'area_id', 'parent_area_code'], 'string', 'max' => 50],
            [['area_name', 'area_name_eng'], 'string', 'max' => 150],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'area_code_lvl_id' => 'Area Code Lvl ID',
            'area_code' => 'Area Code',
            'area_id' => 'Area ID',
            'area_name' => 'Area Name',
            'area_name_eng' => 'Area Name Eng',
            'area_type' => 'Area Type',
            'parent_area_code' => 'Parent Area Code',
            'tag_data' => 'Tag Data',
        ];
    }
}
