<frameset cols="220,*" frameborder="yes" border="1" id="Fr1">
<frame src="/statics/html/left.php" scrolling="no" frameborder="1" name="left"  id="leftframe">
<frameset rows="50%,*" frameborder="yes" border="7" id="Fr2"  framespacing="7">
    <frame src="/statics/html/top.php" scrolling="Auto" frameborder="yes" name="top" id="topframe">
    <frame src="/statics/html/bottom.php" name="bottom" frameborder="yes" scrolling="Auto" id="bottomframe">
</frameset>
</frameset><noframes></noframes>




