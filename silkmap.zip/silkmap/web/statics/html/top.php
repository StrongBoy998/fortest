<div class="content">
    <div id="graph" style="width: 100%;height:100%;" ></div>
</div>

<div class="bottom" id="tooltip">
    <p id="p1">GDP / <span>单位: 万元</span></p>
    <img src="/statics/images/title_bg.png" alt="">
    <hr>
</div>

<link rel="stylesheet" href="/statics/css/top.css">
<script type="text/javascript" src="/statics/js/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/script.js"></script>
<script src="/statics/js/echarts.min.js"></script>
<script type="text/javascript" src="/statics/js/graph_init.js"></script>

