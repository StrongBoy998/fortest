<div id="left">
  <h1>数据列表</h1>
        <div id="content">
            <div class="first"><input id="kw"   class="search"  onKeyup="getContent(this);" placeholder="请输入关键字" />
                <input type="button"  class="button" id="search"></div>
            <div id="append"></div>
        </div>
  <div id="nav" class="nav_box">

</div>
<link rel="stylesheet" href="/statics/css/left.css">
<script type="text/javascript" src="/statics/js/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/script.js"></script>
<script type="text/javascript" src="/statics/js/search.js"></script>
<script>
    $(document).ready(function(){
         $('#nav').find('div:first').css('display','block')
    });
</script>
