
<div class="content">
    <div class="con_box">
        <table border="1" cellspacing="0" align="center" id="table">
            <tr class="bor_top">
                <td>国家/时间</td>
                <td>2016</td>
                <td>2015</td>
                <td>2014</td>
                <td>2013</td>
                <td>2012</td>
                <td>2011</td>
                <td>2010</td>
                <td>2009</td>
                <td>2008</td>
                <td>2007</td>
                <td>2006</td>
                <td>2005</td>
                <td>2004</td>
                <td>2003</td>
                <td>2002</td>
                <td>2001</td>
                <td>2000</td>
                <td>1999</td>
                <td>1998</td>
                <td>1997</td>
                <td>1996</td>
                <td>数据来源</td>
            </tr>



        </table>
    </div>
</div>
<div class="bottom">
    <input type="button" id="export" value="导出表格">
</div>
<link rel="stylesheet" href="/statics/css/bottom.css">
<script type="text/javascript" src="/statics/js/jquery.min.js"></script>
<script type="text/javascript" src="/statics/js/script.js"></script>
<script type="text/javascript" src="/statics/js/dataGrid_init.js"></script>


