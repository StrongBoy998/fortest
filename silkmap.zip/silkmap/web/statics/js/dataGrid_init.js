var indc_id = '@1DV';
$.get('/findicatordata/getdata1',{"indc_id":indc_id},function (data) {
    var datas = JSON.parse(data)['data'];
    var tooltip = JSON.parse(data)['tooltip'];
    for(var i in datas) {//不使用过滤
        var str = '<tr> <td>' + i + '</td> <td>' + datas[i][2016] + '</td> <td>' + datas[i][2015] + '</td> <td>' + datas[i][2014] + '</td> <td>' + datas[i][2013] + '</td> <td>' + datas[i][2012] + '</td>  <td>' + datas[i][2011] + '</td>  <td>' + datas[i][2010] + '</td>  <td>' + datas[i][2009] + '</td><td>' + datas[i][2008] + '</td><td>' + datas[i][2007] + '</td><td>' + datas[i][2006] + '</td><td>' + datas[i][2005] + '</td><td>' + datas[i][2004] + '</td><td>' + datas[i][2003] + '</td><td>' + datas[i][2002] + '</td><td>' + datas[i][2001] + '</td><td>' + datas[i][2000] + '</td><td>' + datas[i][1999] + '</td><td>' + datas[i][1998] + '</td><td>' + datas[i][1997] + '</td><td>' + datas[i][1996] + '</td><td>' + tooltip['indc_source'] + '</td></tr>';
        $("#table").append(str)
    }
})