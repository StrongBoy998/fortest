//折线图
var indc_id = '@1DV';
var date_id = '2006';
//韩国 新西兰 叙利亚  泰国 伊朗 巴基斯坦 菲律宾 新加坡 越南  埃及 波兰 土耳其
var area_code_lvl_id = ["176_2_173","236_2_233","241_2_238","283_2_114","292_2_184","293_2_191","294_2_218","297_2_260","298_2_70","312_2_193","315_2_245"];
$.get('/findicatordata/getdata5',{"indc_id":indc_id,"date_id":date_id,"area_code_lvl_id":area_code_lvl_id},function (data) {
    var datas = JSON.parse(data)['data'];
    var tooltip = JSON.parse(data)['tooltip'];
    var area = [];
    var val = [];
    for(var i in datas){
        area.push(i);
        val.push(parseFloat(datas[i]));
    }
    option = {
        title: {
            text:  date_id+"年 "+tooltip['indc_id_name'],
            left: 'center',
            subtext: '来源'+tooltip['indc_source'],
        },
        tooltip : {
            trigger: 'axis',
            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            show: true,
            // orient: 'vertical',
            left :50,
            feature: {
                mark: {
                    show: true
                },

                restore: {
                    show: true
                },
                saveAsImage: {
                    show: true
                }
            }
        },
        xAxis : [
            {
                type : 'category',
                data : area,
                axisTick: {
                    alignWithLabel: true
                }
            }
        ],
        yAxis : [
            {
                type : 'value',
                name: '单位: '+tooltip['load_unit_name'],
            }
        ],
        series : [
            {
                label: {
                    normal: {
                        show: true,
                        position: 'top'
                    }
                },
                name:'值',
                type:'bar',
                barWidth: '60%',
                data:val
            }

        ],
    };
    var myChart = echarts.init(document.getElementById('graph'));
    myChart.setOption(option);
})
