var ifrm1 = document.getElementById('mainiframe');
ifrm1.onload = function(){
    var graph =  document.getElementById('mainiframe').contentWindow.document.getElementById('topframe').contentWindow.document.getElementById('graph');
    var list =  $(document.getElementById('mainiframe').contentWindow.document.getElementById('leftframe').contentWindow.document.getElementsByClassName('menu_body'));
    var table =  document.getElementById('mainiframe').contentWindow.document.getElementById('bottomframe').contentWindow.document.getElementById('table');
    var tooltipinfo = $(document.getElementById('mainiframe').contentWindow.document.getElementById('topframe').contentWindow.document.getElementById('tooltip'));
    var exportdata = $(document.getElementById('mainiframe').contentWindow.document.getElementById('bottomframe').contentWindow.document.getElementById('export'));


    //点击导出按钮
    $(exportdata).click(function () {
        var indc_id = $('#indc_id').text();
        $.get('/findicatordata/export',{"indc_id":indc_id},
            function (data) {
                document.location.href =('/'+data);
            })

    })

    //点击筛选
    $("#confirm").click(function () {
        var area_code_lvl_id = [];
        var countrys  = []; //中文
        var date_id  = "";
        var indc_id = $('#indc_id').text();
        $("#s1").find("font").each(function () {
            area_code_lvl_id.push($(this).attr("value"))
            countrys.push($(this).text())
        })

        $("input[name=time]").each(function () {
            if($(this).parent().attr("class") =="check_checked"){
                date_id =  $(this).val();
            }
        });


        if(area_code_lvl_id.length == 0){
            alert('请至少选择一个国家')
            return false;
        }

        $('#alert').css("display","none");
        var  countrysInfo  =""
        for(var i=0; i<countrys.length;i++){
            countrysInfo +=countrys[i]+"、";
        }
        var countrysInfo =countrysInfo.substring(0,countrysInfo.length-1);
        $(".countrys").text(countrysInfo)
        $(".date_idInfo").text(date_id)
        if(date_id == "所有年份"){
            //折线图

            $.get('/findicatordata/getdata6',{"area_code_lvl_id":area_code_lvl_id,"indc_id":indc_id},function (data) {
                var datas = JSON.parse(data)["data"];
                var tooltip = JSON.parse(data)["tooltip"];
                var info = [];
                for(var i in datas ){
                    info.push( {
                            name:i,
                            type:'line',
                            smooth:true,
                            data:[
                                datas[i]['1996']?datas[i]['1996']:null,
                                datas[i]['1997']?datas[i]['1997']:null,
                                datas[i]['1998']?datas[i]['1998']:null,
                                datas[i]['1999']?datas[i]['1999']:null,
                                datas[i]['2000']?datas[i]['2000']:null,
                                datas[i]['2001']?datas[i]['2001']:null,
                                datas[i]['2002']?datas[i]['2002']:null,
                                datas[i]['2003']?datas[i]['2003']:null,
                                datas[i]['2004']?datas[i]['2004']:null,
                                datas[i]['2005']?datas[i]['2005']:null,
                                datas[i]['2006']?datas[i]['2006']:null,
                                datas[i]['2007']?datas[i]['2007']:null,
                                datas[i]['2008']?datas[i]['2008']:null,
                                datas[i]['2009']?datas[i]['2009']:null,
                                datas[i]['2010']?datas[i]['2010']:null,
                                datas[i]['2011']?datas[i]['2011']:null,
                                datas[i]['2012']?datas[i]['2012']:null,
                                datas[i]['2013']?datas[i]['2013']:null,
                                datas[i]['2014']?datas[i]['2014']:null,
                                datas[i]['2015']?datas[i]['2015']:null,
                                datas[i]['2016']?datas[i]['2016']:null,
                            ]
                        }
                    );

                }

                option = {
                    title : {
                        text: tooltip['indc_id_name'],
                        left: 'center',
                        subtext: '来源 '+tooltip['indc_source']
                    },
                    tooltip : {
                        trigger: 'axis'
                    },

                    toolbox: {
                        show : true,
                        left :50,
                        // orient: 'vertical',
                        feature : {
                            mark : {show: true},
                            // magicType : {show: true, type: ['line', 'bar']},
                            restore : {show: true},
                            saveAsImage : {show: true}
                        }
                    },
                    calculable : true,
                    xAxis : [
                        {
                            type : 'category',
                            boundaryGap : false,
                            data : ['1996','1997','1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011', '2012','2013','2014','2015','2016'
                            ]
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value',
                            name : '单位 '+tooltip['load_unit_name'],
                        }
                    ],
                    series : info
                };
                var myChart = echarts.init(graph);
                myChart.setOption(option);
            })
        }else{//时间为某一年时间的时候  曲线图
            $.get('/findicatordata/getdata5',{"indc_id":indc_id,"date_id":date_id,"area_code_lvl_id":area_code_lvl_id},function (data) {
                console.log(data)
                var datas = JSON.parse(data)['data'];
                var tooltip = JSON.parse(data)['tooltip'];
                var area = [];
                var val = [];
                for(var i in datas){
                    area.push(i);
                    val.push(parseFloat(datas[i]));
                }
                option = {
                    title: {
                        text:  date_id+"年 "+tooltip['indc_id_name'],
                        left: 'center',
                        subtext: '来源'+tooltip['indc_source'],
                    },
                    tooltip : {
                        trigger: 'axis',
                        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        }
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    toolbox: {
                        show: true,
                        // orient: 'vertical',
                        left :50,
                        feature: {
                            mark: {
                                show: true
                            },

                            restore: {
                                show: true
                            },
                            saveAsImage: {
                                show: true
                            }
                        }
                    },
                    xAxis : [
                        {
                            type : 'category',
                            data : area,
                            axisTick: {
                                alignWithLabel: true
                            }
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value',
                            name: '单位: '+tooltip['load_unit_name'],
                        }
                    ],
                    series : [
                        {
                            label: {
                                normal: {
                                    show: true,
                                    position: 'top'
                                }
                            },
                            name:'值',
                            type:'bar',
                            barWidth: '60%',
                            data:val
                        }

                    ],
                };
                var myChart = echarts.init(graph);
                myChart.setOption(option);
            })
        }
    })

    list.find("a").click(function () {
        //重置默认
        $(".countrys").text("新西兰、叙利亚、泰国、伊朗、巴基斯坦、菲律宾、新加坡、越南、埃及、波兰、土耳其")
        $(".date_idInfo").text("2006")

        var indc_id =  $(this).attr("value");
        $('#indc_id').text(indc_id)
        var date_id = '2006';
        var area_code_lvl_id = ["176_2_173","236_2_233","241_2_238","283_2_114","292_2_184","293_2_191","294_2_218","297_2_260","298_2_70","312_2_193","315_2_245"];
        $(table).find("tr:not(:first)").remove();
        $.get('/findicatordata/getdata1',{"indc_id":indc_id},function (data) {
            var tooltip = JSON.parse(data)['tooltip'];

            var datas = JSON.parse(data)['data'];

            for(var i in datas) {//不使用过滤
                var str = '<tr> <td>' + i + '</td> <td>' + datas[i][2016] + '</td> <td>' + datas[i][2015] + '</td> <td>' + datas[i][2014] + '</td> <td>' + datas[i][2013] + '</td> <td>' + datas[i][2012] + '</td>  <td>' + datas[i][2011] + '</td>  <td>' + datas[i][2010] + '</td>  <td>' + datas[i][2009] + '</td><td>' + datas[i][2008] + '</td><td>' + datas[i][2007] + '</td><td>' + datas[i][2006] + '</td><td>' + datas[i][2005] + '</td><td>' + datas[i][2004] + '</td><td>' + datas[i][2003] + '</td><td>' + datas[i][2002] + '</td><td>' + datas[i][2001] + '</td><td>' + datas[i][2000] + '</td><td>' + datas[i][1999] + '</td><td>' + datas[i][1998] + '</td><td>' + datas[i][1997] + '</td><td>' + datas[i][1996] + '</td><td>' + tooltip['indc_source'] + '</td></tr>';
                $(table).append(str)
            }
        })

        //柱状图
        $.get('/findicatordata/getdata5',{"indc_id":indc_id,"date_id":date_id,"area_code_lvl_id":area_code_lvl_id},function (data) {

            var datas = JSON.parse(data)['data'];
            var tooltip = JSON.parse(data)['tooltip'];
            tooltipinfo.find("#p1").html(tooltip['indc_id_name']+" / <span>单位: "+tooltip['load_unit_name']+"</span>")
            var area = [];
            var val = [];
            for(var i in datas){
                area.push(i);
                val.push(parseFloat(datas[i]));
            }
            option = {
                title: {
                    text:  date_id+"年 "+tooltip['indc_id_name'],
                    left: 'center',
                    subtext: '来源'+tooltip['indc_source'],
                },
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    show: true,
                    // orient: 'vertical',
                    left :50,
                    feature: {
                        mark: {
                            show: true
                        },

                        restore: {
                            show: true
                        },
                        saveAsImage: {
                            show: true
                        }
                    }
                },
                xAxis : [
                    {
                        type : 'category',
                        data : area,
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value',
                        name: '单位: '+tooltip['load_unit_name'],
                    }
                ],
                series : [
                    {
                        label: {
                            normal: {
                                show: true,
                                position: 'top'
                            }
                        },
                        name:'值',
                        type:'bar',
                        barWidth: '60%',
                        data:val
                    }

                ],
            };
            var myChart = echarts.init(graph);
            myChart.setOption(option);
        })
    })
};