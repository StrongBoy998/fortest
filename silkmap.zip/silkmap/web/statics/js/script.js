// JavaScript Document
$(document).ready(function(){



//nav
	$("#nav .menu_body:eq(0)").show();
	$("#nav p.menu_head").click(function(){
		$(this).addClass("current").next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
		$(this).siblings().removeClass("current");
	});
	$("#secondpane .menu_body:eq(0)").show();
	$("#secondpane p.menu_head").mouseover(function(){
		$(this).addClass("current").next("div.menu_body").slideDown(500).siblings("div.menu_body").slideUp("slow");
		$(this).siblings().removeClass("current");
	});

    $("#navmap .menu_body:eq(0)").show();
    $("#navmap p.menu_head").click(function(){
        $(this).addClass("current").next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
        $(this).siblings().removeClass("current");
    });
    $("#secondpane .menu_body:eq(0)").show();
    $("#secondpane p.menu_head").mouseover(function(){
        $(this).addClass("current").next("div.menu_body").slideDown(500).siblings("div.menu_body").slideUp("slow");
        $(this).siblings().removeClass("current");
    });


//鼠标经过	
	$('.now').mouseover(function(){
		$(this).children('.detail').stop().show(800);
	});
	$('.now').mouseout(function(){
		$(this).children('.detail').stop().hide(500);
	});
	
	
//点击事件	
	$('#choose').click(function() {
		$('#alert').css("display","block");
	});
	$('#close').click(function() {
		$('#alert').css("display","none");
	});
	$('.checked_box').children().click(function() {
		$(this).css("display","none");
	});











});

