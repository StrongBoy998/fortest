$("input[name=country]").click(function () {
    var  clickval = $(this).parent().text();
    var  area_id = $(this).val();
    var selectInfo = [];
    $('#s1').find("font").each(function() {
        selectInfo.push($(this).text());
    });

    if(jQuery.inArray(clickval, selectInfo) == -1){
        $(this).parent().addClass("check_checked")
        $("#s1").find("div").before('<font style="color: #00fff6;" value="'+area_id+'">'+clickval+'<span></span></font>');
        $('#s1').find("font").on('click',function() {
            var selectval = $(this).text();
            $("input[name=country]").parent().each(function() {
                if($(this).text()==selectval){
                    $(this).removeClass("check_checked")
                };
            });
            $(this).remove();
        });
    }else{
        $(this).parent().removeClass("check_checked")
        $('#s1').find("font").each(function() {
            if($(this).text()==clickval){
                $(this).remove();
            };
        });
    }
});

$(".time label").click(function(){
    $(this).addClass("check_checked");
    $(this).siblings().removeClass("check_checked");
});


$("#reset").click(function () {
    $('#s2').find("font").remove();
    $('#s1').find("font").remove();
    $("input[name=country]").parent().removeClass("check_checked");
    $("input[name=time]").parent().removeClass("check_checked");
})