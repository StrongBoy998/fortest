<?php
use yii\helpers\Url;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>首页大数据工作流平台</title>
    <link href='http://fonts.googleapis.com/css?family=Oswald:400,300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Abel' rel='stylesheet' type='text/css'>
    <link href="./statics/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
    <div id="header-wrapper">
        <div id="header" class="container">
            <div id="logo" style="margin-top: 40px">
                <img src="./statics/images/img04.png" width="180" height="60" alt="">
            </div>
            <div id="menu">
                <ul>
                    <li ><a href="<?= Url::to(['baiduzhiku/crawl-news/index']);?>">首页智库</a></li>
                    <li><a href="<?= Url::to(['baidupolicy/faguimsg/index']);?>">首页政策</a></li>
                    <li><a href="http://192.168.1.19:8080/wechat/">微信爬虫</a></li>
                    <li><a href="#">N/A</a></li>
                    <li><a href="#">N/A</a></li>
                </ul>
            </div>
        </div>
        <div id="banner">
            <div class="content"><img src="./statics/images/img02.png" width="1000" height="300" alt="" /></div>
        </div>
    </div>
    <!-- end #header -->

    <div id="page">
        <div id="content">
            <div class="post">
                <h2 class="title"><a href="#">Read Me</a></h2>
                <div style="clear: both;">&nbsp;</div>
                <div class="entry">
                    <p></p>
                    <p>微信爬虫 帐号:admin 密码:123456<strong></strong></p>
                    <p class="links"><a href="#" class="more">阅读更多</a></p>
                </div>
            </div>

            <div style="clear: both;">&nbsp;</div>
        </div>
        <!-- end #content -->
        <div id="sidebar">
            <ul>
                <li>
                    <h2>分类</h2>
                    <ul>
                        <li><a href="<?= Url::to(['baiduzhiku/crawl-news/index']);?>">首页智库</a></li>
                        <li><a href="<?= Url::to(['baidupolicy/faguimsg/index']);?>">首页政策</a></li>
                        <li><a href="http://192.168.1.19:8080/wechat/">微信爬虫</a></li>
                        <li><a href="#">N/A</a></li>
                        <li><a href="#">N/A</a></li>
                        <li><a href="#">N/A</a></li>
                    </ul>
                </li>

            </ul>
        </div>
        <!-- end #sidebar -->
        <div style="clear: both;">&nbsp;</div>
    </div>
    <!-- end #page -->
</div>
<div id="footer">
    <p>Copyright (c) 2017 首页大数据 &nbsp; <a href="http://www.12340.net.cn/" rel="nofollow">关于我们</a></p>
</div>
<!-- end #footer -->
</body>
</html>
