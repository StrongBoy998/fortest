<?php

namespace app\modules\baidupolicy\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\modules\baidupolicy\models\Faguimsg;

/**
 * FaguimsgSearch represents the model behind the search form about `app\modules\baidupolicy\models\Faguimsg`.
 */
class FaguimsgSearch extends Faguimsg
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['newsId', 'crawlStamp', 'status'], 'integer'],
            [['uniqueCode', 'unitName', 'publicUrl', 'polocyName', 'publicTime'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {

        // add conditions that should always apply here
        $query = Faguimsg::find();
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'crawlStamp' => $this->crawlStamp,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'uniqueCode', $this->uniqueCode])
            ->andFilterWhere(['like', 'unitName', $this->unitName])
            ->andFilterWhere(['like', 'publicUrl', $this->publicUrl])
            ->andFilterWhere(['like', 'polocyName', $this->polocyName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime]);

        return $dataProvider;
    }


    public function search1($params)
    {
        $start = strtotime($params['id']['date'][0]);
        $end = strtotime($params['id']['date'][1]);
        $query = Faguimsg::find()->where(['unitName'=>explode(",",$params['id']['hid'])])->andWhere("unix_timestamp(publicTime) BETWEEN $start AND $end");

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'crawlStamp' => $this->crawlStamp,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'uniqueCode', $this->uniqueCode])
            ->andFilterWhere(['like', 'unitName', $this->unitName])
            ->andFilterWhere(['like', 'publicUrl', $this->publicUrl])
            ->andFilterWhere(['like', 'polocyName', $this->polocyName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime]);

        return $dataProvider;
    }
}
