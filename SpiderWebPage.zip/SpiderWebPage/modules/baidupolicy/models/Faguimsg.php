<?php

namespace app\modules\baidupolicy\models;

use Yii;

/**
 * This is the model class for table "faguimsg".
 *
 * @property string $newsId
 * @property string $uniqueCode
 * @property string $unitName
 * @property string $publicUrl
 * @property string $polocyName
 * @property string $publicTime
 * @property integer $crawlStamp
 * @property integer $status
 */
class Faguimsg extends \yii\db\ActiveRecord
{
    public static function getDb()
    {
        return Yii::$app->baidupolicy_db;
    }
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'faguiMsg';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['uniqueCode', 'unitName', 'publicUrl', 'polocyName'], 'required'],
            [['unitName', 'publicUrl', 'polocyName'], 'string'],
            [['crawlStamp', 'status'], 'integer'],
            [['uniqueCode'], 'string', 'max' => 200],
            [['publicTime'], 'string', 'max' => 60],
            [['uniqueCode'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'newsId' => 'ID',
            'uniqueCode' => 'Unique Code',
            'unitName' => '发布单位',
            'publicUrl' => 'Url',
            'polocyName' => '文章标题',
            'publicTime' => '发布时间',
            'crawlStamp' => 'Crawl Stamp',
            'status' => '状态',
        ];
    }

    public function getunitName(){
        return Faguimsg::find()->select('unitName')->groupBy('unitName')->asArray()->all();
    }
}
