<?php  use kartik\date\DatePicker;
$this->params['breadcrumbs'][] = '部委和国务院直属机构发布政策爬虫导出excel';
?>

<form action="" method="post" target="_blank">


    <link rel="stylesheet" type="text/css" href="statics/js/hdw.css">
    <script type="text/javascript" src="statics/js/jquery.min.js"></script>
    <script type="text/javascript" src="statics/js/hdw.js"></script>



    <?php
echo DatePicker::widget([
    'name' => 'date[]',
    'value' => '',
    'type' => DatePicker::TYPE_RANGE,
    'name2' => 'date[]',
    'value2' => '',
    'options' => ['placeholder' => '开始日期'],
    'options2' => ['placeholder' => '结束日期'],
    'pluginOptions' => [
        'autoclose' => true,
        'format' => 'yyyy-mm-dd',
        'todayHighlight' => true
    ],
    'language'=>'zh-CN',
]);
?>



    <br/>


    <div class="content">

        <select multiple="multiple" id="select1">

            <?php foreach ($unitname as $v): ?>
                        <?php echo  " <option value=''>".$v['unitName']."</option>"; ?>
                    <?php endforeach; ?>

        </select>

        <span id="add">选中右移>></span> <span id="add_all">全部右移>></span></div>

    <div class="content">

        <select multiple="multiple" id="select2">

        </select>

        <span id="remove">选中左移>></span><span id="remove_all">全部左移>></span>

    </div>
    <input type="hidden" name="hid" value="" id="hid">
 <input name="_csrf" type="hidden" id="_csrf" value="<?= Yii::$app->request->csrfToken ?>">
<input type="button"  class="btn btn-primary"  id="export" value="导出数据">
    </br>
    </br>
    </br>
<input type="submit"  class="btn  btn-primary"  id="showdata"  value="展示数据">
</form>

<script>

    $("#showdata").click(function () {
        var seldata = [];
        $("#select2").find("option").each(function () {
            seldata.push($(this).text())
        })
        $("#hid").val(seldata)
    })


    $("#export").click(function () {
        var starttime = $("#w0").val()
        var endtime = $("#w0-2").val()
        var seldata = [];
        $("#select2").find("option").each(function () {
            seldata.push($(this).text())
        });
        if(seldata.length == 0){
            alert('请选择发布单位')
            return;
        }

        if(starttime == "" ||endtime ==""){
            alert('请选择时间')
            return;
        }
        $.get("index.php?r=baidupolicy/faguimsg/export-data",{"starttime":starttime,"endtime":endtime,"sel":seldata},function (data) {
            if(data == 1){
                document.location.href =('/SpiderWebPage/web/exportData/Policy.xls');
            }else{
                alert('下载失败 请稍候')
                return;
            }

        })

    })
</script>