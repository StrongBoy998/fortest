<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\baidupolicy\models\Faguimsg */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="faguimsg-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'uniqueCode')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'unitName')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'publicUrl')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'polocyName')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'publicTime')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'crawlStamp')->textInput() ?>

    <?= $form->field($model, 'status')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
