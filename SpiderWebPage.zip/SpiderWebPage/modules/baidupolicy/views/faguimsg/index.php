<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\modules\baidupolicy\models\FaguimsgSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '部委和国务院直属机构发布政策爬虫';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="faguimsg-index">

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
//        'filterModel' => $searchModel,
        'pager'=>[
            'firstPageLabel'=>"首页",
            'prevPageLabel'=>'上一页',
            'nextPageLabel'=>'下一页',
            'lastPageLabel'=>'末页',
        ],
        'columns' => [
//            ['class' => 'yii\grid\SerialColumn'],

            'newsId',
//            'uniqueCode',
            'unitName:ntext',
            [
                'attribute' => 'publicUrl',
                'value' => function ($model) {
                    return Html::a('<span class ="glyphicon glyphicon-link"></span>', "{$model->publicUrl}", ['target' => '_blank']);
                },
                'format' => 'raw',
            ],
            'polocyName:ntext',
             'publicTime',
//             'crawlStamp',
//             'status',
//            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
