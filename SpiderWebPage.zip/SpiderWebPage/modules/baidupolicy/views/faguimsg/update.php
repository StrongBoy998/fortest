<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\modules\baidupolicy\models\Faguimsg */

$this->title = 'Update Faguimsg: ' . $model->newsId;
$this->params['breadcrumbs'][] = ['label' => 'Faguimsgs', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->newsId, 'url' => ['view', 'id' => $model->newsId]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="faguimsg-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
