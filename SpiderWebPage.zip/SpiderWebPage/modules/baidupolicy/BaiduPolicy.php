<?php

namespace app\modules\baidupolicy;

class BaiduPolicy extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\baidupolicy\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
