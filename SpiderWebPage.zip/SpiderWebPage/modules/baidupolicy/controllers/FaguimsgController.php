<?php

namespace app\modules\baidupolicy\controllers;

use Yii;
use app\modules\baidupolicy\models\Faguimsg;
use app\modules\baidupolicy\models\FaguimsgSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use PHPExcel;

/**
 * FaguimsgController implements the CRUD actions for Faguimsg model.
 */
class FaguimsgController extends Controller
{
    public $layout = 'main';
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Faguimsg models.
     * @return mixed
     */

    public function actionExport()
    {
        if (!Yii::$app->request->isPost) {
            $unitname = Faguimsg::getunitName();
            return $this->render('export',['unitname'=>$unitname]);
        }else{
            if(empty($_POST['date'][0])||empty($_POST['date'][1])){
                return  "请选择时间";
            }
            if(empty($_POST['hid'])){
                return "请选择发布单位";
            }
            $this->redirect(array('showdata','id'=>$_POST));

        }
    }

    public function actionExportData()
    {

        //设置北京时区
//            ini_set('date.timezone','Asia/Shanghai');
        //设置php超时时间
        ini_set("max_execution_time", "3600");
        ini_set('memory_limit', '512M');
        $start = strtotime(Yii::$app->request->get('starttime'));
        $end = strtotime(Yii::$app->request->get('endtime'));
        $seldata = Yii::$app->request->get('sel');
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', '发布单位')
            ->setCellValue('B1', 'Url')
            ->setCellValue('C1', '文章标题')
            ->setCellValue('D1', '发布时间');

        //从从数据库查出数据
        $datas = Faguimsg::find()->select("unitName, publicUrl, polocyName, publicTime"
        )->where("unix_timestamp(publicTime) BETWEEN $start AND $end")->andWhere(['unitName' => $seldata])->asArray()->all();
        $i = 2;
        foreach ($datas as $data) {

            $objectPHPExcel->setActiveSheetIndex(0)
                ->setCellValue("A$i", $data['unitName'])
                ->setCellValue("B$i", $data['publicUrl'])
                ->setCellValue("C$i", $data['polocyName'])
                ->setCellValue("D$i", $data['publicTime']);
            $i++;
        }

        //防止乱码
        ob_end_clean();
        ob_start();
        header('Content-Type : application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename="' . '部委和国务院直属机构发布政策爬虫-' . date("Y年m月d日", $start) . '-' . date("Y年m月d日", $end) . '.xls"');

        $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
        $objWriter->save('exportData/Policy.xls');
        return 1;
    }

    public function actionIndex()
    {
        $searchModel = new FaguimsgSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionShowdata()
    {

        $searchModel = new FaguimsgSearch();
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
        return $this->render('showdata', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Faguimsg model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Faguimsg model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
//    public function actionCreate()
//    {
//        $model = new Faguimsg();
//
//        if ($model->load(Yii::$app->request->post()) && $model->save()) {
//            return $this->redirect(['view', 'id' => $model->newsId]);
//        } else {
//            return $this->render('create', [
//                'model' => $model,
//            ]);
//        }
//    }

    /**
     * Updates an existing Faguimsg model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
//    public function actionUpdate($id)
//    {
//        $model = $this->findModel($id);
//
//        if ($model->load(Yii::$app->request->post()) && $model->save()) {
//            return $this->redirect(['view', 'id' => $model->newsId]);
//        } else {
//            return $this->render('update', [
//                'model' => $model,
//            ]);
//        }
//    }

    /**
     * Deletes an existing Faguimsg model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
//    public function actionDelete($id)
//    {
//        $this->findModel($id)->delete();
//
//        return $this->redirect(['index']);
//    }

    /**
     * Finds the Faguimsg model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Faguimsg the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Faguimsg::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
