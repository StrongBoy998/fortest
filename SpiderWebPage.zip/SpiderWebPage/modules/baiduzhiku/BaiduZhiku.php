<?php

namespace app\modules\baiduzhiku;

class BaiduZhiku extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\baiduzhiku\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
