<?php

namespace app\modules\baiduzhiku\models;

use Yii;

/**
 * This is the model class for table "item".
 *
 * @property integer $id
 * @property string $itemname
 * @property string $starttime
 * @property string $endtime
 * @property integer $status
 */
class Item extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['status'], 'integer'],
            [['itemname'], 'string', 'max' => 35],
            [['starttime', 'endtime'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {

        return [
            'id' => '项目编号',
            'itemname' => '项目名',
            'starttime' => '项目开始时间',
            'endtime' => '项目结束时间',
            'status' => '状态',
        ];
    }
}
