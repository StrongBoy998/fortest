<?php

namespace app\modules\baiduzhiku\models;

use Yii;

/**
 * This is the model class for table "keyws".
 *
 * @property string $id
 * @property string $keysName
 */
class Keyws extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'keyws';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['keysName'], 'required'],
            [['keysName'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'keysName' => '爬虫关键词管理',
        ];
    }
}
