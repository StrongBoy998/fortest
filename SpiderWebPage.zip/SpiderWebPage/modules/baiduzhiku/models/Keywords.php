<?php

namespace app\modules\baiduzhiku\models;

use Yii;

/**
 * This is the model class for table "keywords".
 *
 * @property integer $id
 * @property string $determine
 * @property string $industryType
 * @property string $topicType
 * @property string $zhikuTrends
 */
class Keywords extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'keywords';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'required'],
            [['id'], 'integer'],
            [['determine', 'industryType', 'topicType', 'zhikuTrends', 'partybuilding', 'anticorruption', 'politics', 'culture', 'diplomacy', 'military', 'peoplelivelihood', 'environmentalprotection', 'medicaltreatment', 'education', 'agriculture', 'technology', 'judicature', 'energy', 'antiterrorist'], 'string', 'max' => 500],
            [['economic', 'administrative'], 'string', 'max' => 700],
            [['policysuggestion', 'policyanalyzing', 'expertremarks', 'internationalcommentary', 'signedarticles', 'seminar', 'lecturesexchange', 'internationalconference', 'resultsreleased', 'leadingvisit', 'internationalvisit', 'instruction', 'researchguidance', 'foreignmediaattention', 'projectcooperation', 'globalcooperation', 'thinktankconstruction', 'winningtrends', 'researchdynamics', 'personnelchange'], 'string', 'max' => 200],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'determine' => '屏蔽词',
            'industryType' => '行业分类关键词',
            'topicType' => '话题分类关键词',
            'zhikuTrends' => '智库动态关键词',
            'economic' => '经济',
            'administrative' => '行政',
            'partybuilding' => '建党',
            'anticorruption' => '反腐',
            'politics' => '政治',
            'culture' => '文化',
            'diplomacy' => '外交',
            'military' => '军事',
            'peoplelivelihood' => '民生',
            'environmentalprotection' => '环保',
            'medicaltreatment' => '医疗',
            'education' => '教育',
            'agriculture' => '农业',
            'technology' => '科技',
            'judicature' => '司法',
            'energy' => '能源',
            'antiterrorist' => '反恐',
            'policysuggestion' => '政策建议',
            'policyanalyzing' => '政策解读',
            'expertremarks' => '专家言论',
            'internationalcommentary' => '国际时评',
            'signedarticles' => '署名文章',
            'seminar' => '座谈会/研讨会',
            'lecturesexchange' => '讲学交流',
            'internationalconference' => '国际会议发言',
            'resultsreleased' => '成果发布',
            'leadingvisit' => '领导来访',
            'internationalvisit' => '国际访问',
            'instruction' => '指示批示',
            'researchguidance' => '调研指导',
            'foreignmediaattention' => '外媒关注',
            'projectcooperation' => '项目合作',
            'globalcooperation' => '国际合作',
            'thinktankconstruction' => '智库建设',
            'winningtrends' => '获奖动态',
            'researchdynamics' => '研究动态',
            'personnelchange' => '人事变动',
        ];
    }


    //从数据库查询对应的过滤词汇
    public static function getdata()
    {
        $data = Keywords::find()->where(['id' => 1])->asArray()->one();
        $determine = explode("，", trim($data['determine'],'，'));
        $industryType = explode("，", trim($data['industryType'],'，'));
        $topicType = explode("，", trim($data['topicType'],'，'));
        $zhikuTrends = explode("，", trim($data['zhikuTrends'],'，'));
        $economic = explode("，", trim($data['economic'],'，'));
        $administrative = explode("，", trim($data['administrative'],'，'));
        $partybuilding = explode("，", trim($data['partybuilding'],'，'));
        $anticorruption= explode("，", trim($data['anticorruption'],'，'));
        $politics = explode("，", trim($data['politics'],'，'));
        $culture= explode("，", trim($data['culture'],'，'));
        $diplomacy = explode("，", trim($data['diplomacy'],'，'));
        $military = explode("，", trim($data['military'],'，'));
        $peoplelivelihood = explode("，", trim($data['peoplelivelihood'],'，'));
        $environmentalprotection = explode("，", trim($data['environmentalprotection'],'，'));
        $medicaltreatment = explode("，", trim($data['medicaltreatment'],'，'));
        $education = explode("，", trim($data['education'],'，'));
        $agriculture = explode("，", trim($data['agriculture'],'，'));
        $technology = explode("，", trim($data['technology'],'，'));
        $judicature = explode("，", trim($data['judicature'],'，'));
        $energy = explode("，", trim($data['energy'],'，'));
        $antiterrorist = explode("，", trim($data['antiterrorist'],'，'));

        $policysuggestion = explode("，", trim($data['policysuggestion'],'，'));
        $policyanalyzing = explode("，", trim($data['policyanalyzing'],'，'));
        $expertremarks = explode("，", trim($data['expertremarks'],'，'));
        $internationalcommentary = explode("，", trim($data['internationalcommentary'],'，'));
        $signedarticles = explode("，", trim($data['signedarticles'],'，'));
        $seminar = explode("，", trim($data['seminar'],'，'));
        $lecturesexchange = explode("，", trim($data['lecturesexchange'],'，'));
        $internationalconference = explode("，", trim($data['internationalconference'],'，'));
        $resultsreleased = explode("，", trim($data['resultsreleased'],'，'));
        $leadingvisit = explode("，", trim($data['leadingvisit'],'，'));
        $internationalvisit = explode("，", trim($data['internationalvisit'],'，'));
        $instruction = explode("，", trim($data['instruction'],'，'));
        $researchguidance = explode("，", trim($data['researchguidance'],'，'));
        $foreignmediaattention = explode("，", trim($data['foreignmediaattention'],'，'));
        $projectcooperation= explode("，", trim($data['projectcooperation'],'，'));
        $globalcooperation = explode("，", trim($data['globalcooperation'],'，'));
        $thinktankconstruction = explode("，", trim($data['thinktankconstruction'],'，'));
        $winningtrends = explode("，", trim($data['winningtrends'],'，'));
        $researchdynamics = explode("，", trim($data['researchdynamics'],'，'));
        $personnelchange = explode("，", trim($data['personnelchange'],'，'));
        $datas = [];
        //智能过滤,智库动态 话题分类 行业分类
        //经济4 行政 党建 反腐	政治	文化	外交	军事	民生	环保	医疗	教育	农业	科技	司法	能源	反恐
        array_push($datas,
            $determine,
            $zhikuTrends,
            $topicType,
            $industryType,
            $economic,
            $administrative,
            $partybuilding,
            $anticorruption,
            $politics,
            $culture,
            $diplomacy,
            $military,
            $peoplelivelihood,
            $environmentalprotection,
            $medicaltreatment,
            $education,
            $agriculture,
            $technology,
            $judicature,
            $energy,
            $antiterrorist,

            $policysuggestion,
            $policyanalyzing,
            $expertremarks,
            $internationalcommentary,
            $signedarticles,
            $seminar,
            $lecturesexchange,
            $internationalconference,
            $resultsreleased,
            $leadingvisit,
            $internationalvisit,
            $instruction,
            $researchguidance,
            $foreignmediaattention,
            $projectcooperation,
            $globalcooperation,
            $thinktankconstruction,
            $winningtrends,
            $researchdynamics,
            $personnelchange
            );
        return $datas;
    }




}
