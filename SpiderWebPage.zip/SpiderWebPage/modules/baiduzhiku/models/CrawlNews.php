<?php

namespace app\modules\baiduzhiku\models;

use Codeception\PHPUnit\Constraint\Crawler;
use Yii;
use kartik\date\DatePicker;



/**
 * This is the model class for table "crawlNews".
 *
 * @property string $newsId
 * @property string $zhikuName
 * @property string $keyUrl
 * @property string $newsTitle
 * @property string $newsUrl
 * @property string $mediaName
 * @property string $publicTime
 * @property string $abstract
 * @property string $newsDetail
 * @property string $similarNum
 * @property string $similarUrl
 */
class CrawlNews extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'crawlNews';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['zhikuName', 'keyUrl', 'newsTitle', 'newsUrl', 'abstract',  'crawlStamp'], 'required'],
            [['zhikuName', 'keyUrl', 'newsTitle', 'newsUrl', 'abstract',  'similarUrl'], 'string'],
            [['crawlStamp', 'status'], 'integer'],
            [['mediaName'], 'string', 'max' => 100],
            [['publicTime'], 'string', 'max' => 60],
            [['similarNum'], 'string', 'max' => 30],
            [['zhikuTrends', 'industryType'], 'string', 'max' => 10],
            [['topicType'], 'string', 'max' => 16],
        ];
    }


    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'newsId' => 'id',
            'zhikuName' => '智库名',
            'keyUrl' => '请求的关键字url',
            'newsTitle' => '新闻标题',
            'newsUrl' => 'URL',
            'mediaName' => '媒体名字',
            'publicTime' => '发布时间',
            'abstract' => '新闻简要',
//            'newsDetail' => '新闻具体内容',
            'similarNum' => '相同新闻数',
            'similarUrl' => '相同新闻链接',
            'status' => '导出状态',
            'zhikuTrends' => '智库动态',
            'topicType' => '话题分类',
            'industryType' => '行业分类',
        ];
    }

    //获取所有智库的名字
    public function getZkname()
    {
        $datas = CrawlNews::find()->select(['zhikuName'])->groupBy(['zhikuName'])->asArray()->column();
        foreach ($datas as $data) {
            $dat[$data] = $data;
        };
        return $dat;
}

    public function getTime(){
        return DatePicker::widget([
            'name' => 'CrawlNewsSearch[publicTime]',
            'options' => ['placeholder' => '...'],
            //value值更新的时候需要加上
            'value' => '',
            'pluginOptions' => [
                'autoclose' => true,
                'format' => 'yyyy年mm月dd',
                'todayHighlight' => true,
            ],
            'language'=>'zh-CN',
        ]);
    }

    //审核
    //status 默认状态为1   导出
    //       不可用状态设置为0  不导出

    public function approve(){
        $this->status = 1; //设置状态为1 可用
        return ($this->save()?true:false);
    }

    public function unapprove(){
        $this->status = 0; //设置状态为0 不可用
        return ($this->save()?true:false);
    }

    //研判
//    public function judg($zhikuTrends,$topicType,$industryType,$custom){
//
//        if(!empty($custom)){
//            $this->zhikuTrends=$zhikuTrends;
//            $this->topicType=$custom;
//            $this->industryType=$industryType;
//        }else{
//            $this->zhikuTrends=$zhikuTrends;
//            $this->topicType=$topicType;
//            $this->industryType=$industryType;
//        }
//        $this->status = 2; //设置状态为  状态为已研判
//        return ($this->save()?true:false);
//    }

    //修改行业类型
    public function Changeitype($info){
        if(!empty($info)){
            $this->industryType = $info;
        }else{
            return false;
        }
        return $this->save()?true:false;
    }
    //修改行业类型
    public function Changeztrends($info){
        if(!empty($info)){
            $this->zhikuTrends= $info;
        }else{
            return false;
        }
        return $this->save()?true:false;
    }

    public function Changettype($info){
        if(!empty($info)){
            $this->topicType= $info;
        }else{
            return false;
        }
        return $this->save()?true:false;
    }

}
