<?php

namespace app\modules\baiduzhiku\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\modules\baiduzhiku\models\CrawlNews;

/**
 * CrawlNewsSearch represents the model behind the search form about `app\models\CrawlNews`.
 */
class CrawlNewsSearch extends CrawlNews
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['newsId', 'crawlStamp', 'status'], 'integer'],
            [['zhikuName', 'keyUrl', 'newsTitle', 'newsUrl', 'mediaName', 'publicTime', 'abstract', 'similarNum', 'similarUrl', 'zhikuTrends', 'topicType', 'industryType'], 'safe'],
        ];
    }


    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = CrawlNews::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'zhikuName', $this->zhikuName])
            ->andFilterWhere(['like', 'keyUrl', $this->keyUrl])
            ->andFilterWhere(['like', 'newsTitle', $this->newsTitle])
            ->andFilterWhere(['like', 'newsUrl', $this->newsUrl])
            ->andFilterWhere(['like', 'mediaName', $this->mediaName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime])
            ->andFilterWhere(['like', 'abstract', $this->abstract])
//            ->andFilterWhere(['like', 'newsDetail', $this->newsDetail])
            ->andFilterWhere(['like', 'similarNum', $this->similarNum])
            ->andFilterWhere(['like', 'similarUrl', $this->similarUrl]);
//        $dataProvider->sort->defaultOrder=[
//            'newsId'=>SORT_DESC,
//        ];
        $dataProvider->getPagination()->pageSize=50;

        return $dataProvider;
    }


    //过滤使用的model数据
    public function search1($params)
    {
        $query = CrawlNews::find()->where(['status'=>0]);

        // add conditions that should always apply here
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);
//        var_dump($dataProvider);die();
        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'zhikuName', $this->zhikuName])
            ->andFilterWhere(['like', 'keyUrl', $this->keyUrl])
            ->andFilterWhere(['like', 'newsTitle', $this->newsTitle])
            ->andFilterWhere(['like', 'newsUrl', $this->newsUrl])
            ->andFilterWhere(['like', 'mediaName', $this->mediaName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime])
            ->andFilterWhere(['like', 'abstract', $this->abstract])
//            ->andFilterWhere(['like', 'newsDetail', $this->newsDetail])
            ->andFilterWhere(['like', 'similarNum', $this->similarNum])
            ->andFilterWhere(['like', 'similarUrl', $this->similarUrl]);
//        $dataProvider->sort->defaultOrder=[
//            'newsId'=>SORT_DESC,
//        ];
        $dataProvider->getPagination()->pageSize=50;
        return $dataProvider;
    }

    //研判使用的model数据
    public function search2($params)
    {
        $query = CrawlNews::find()->where(['status'=>1])->orWhere(['status'=>2]);
        // add conditions that should always apply here
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);
        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'zhikuName', $this->zhikuName])
            ->andFilterWhere(['like', 'keyUrl', $this->keyUrl])
            ->andFilterWhere(['like', 'newsTitle', $this->newsTitle])
            ->andFilterWhere(['like', 'newsUrl', $this->newsUrl])
            ->andFilterWhere(['like', 'mediaName', $this->mediaName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime])
            ->andFilterWhere(['like', 'abstract', $this->abstract])
//            ->andFilterWhere(['like', 'newsDetail', $this->newsDetail])
            ->andFilterWhere(['like', 'similarNum', $this->similarNum])
            ->andFilterWhere(['like', 'similarUrl', $this->similarUrl])
            ->andFilterWhere(['like', 'zhikuTrends', $this->zhikuTrends])
            ->andFilterWhere(['like', 'topicType', $this->topicType])
            ->andFilterWhere(['like', 'industryType', $this->industryType]);
//        $dataProvider->sort->defaultOrder=[
//            'newsId'=>SORT_DESC,
//        ];
        $dataProvider->getPagination()->pageSize=50;
        return $dataProvider;
    }

    public function  itemdatas($params,$start,$end,$page = 1)
    {
        $query = CrawlNews::find()->where(['status'=>1])->orWhere(['status'=>2])->andWhere(['BETWEEN', 'crawlStamp', $start, $end]);
        // add conditions that should always apply here
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);
        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'zhikuName', $this->zhikuName])
            ->andFilterWhere(['like', 'keyUrl', $this->keyUrl])
            ->andFilterWhere(['like', 'newsTitle', $this->newsTitle])
            ->andFilterWhere(['like', 'newsUrl', $this->newsUrl])
            ->andFilterWhere(['like', 'mediaName', $this->mediaName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime])
            ->andFilterWhere(['like', 'abstract', $this->abstract])
//            ->andFilterWhere(['like', 'newsDetail', $this->newsDetail])
            ->andFilterWhere(['like', 'similarNum', $this->similarNum])
            ->andFilterWhere(['like', 'similarUrl', $this->similarUrl])
            ->andFilterWhere(['like', 'zhikuTrends', $this->zhikuTrends])
            ->andFilterWhere(['like', 'topicType', $this->topicType])
            ->andFilterWhere(['like', 'industryType', $this->industryType]);
        $dataProvider->getPagination()->pageSize=50;
        $dataProvider->getPagination()->page=$page-1;
        return $dataProvider;
    }
    public function searchcho($params)
    {
        $start = strtotime($params['id']['date'][0]);
        $end = strtotime($params['id']['date'][1]);
        $query = CrawlNews::find()->where(['status'=>1])->orWhere(['status'=>2])->andWhere(['zhikuName'=>explode(",",$params['id']['hid'])])->andWhere(['BETWEEN', 'crawlStamp', $start, $end]);
        // add conditions that should always apply here
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);
        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'newsId' => $this->newsId,
            'status' => $this->status,
        ]);

        $query->andFilterWhere(['like', 'zhikuName', $this->zhikuName])
            ->andFilterWhere(['like', 'keyUrl', $this->keyUrl])
            ->andFilterWhere(['like', 'newsTitle', $this->newsTitle])
            ->andFilterWhere(['like', 'newsUrl', $this->newsUrl])
            ->andFilterWhere(['like', 'mediaName', $this->mediaName])
            ->andFilterWhere(['like', 'publicTime', $this->publicTime])
            ->andFilterWhere(['like', 'abstract', $this->abstract])
//            ->andFilterWhere(['like', 'newsDetail', $this->newsDetail])
            ->andFilterWhere(['like', 'similarNum', $this->similarNum])
            ->andFilterWhere(['like', 'similarUrl', $this->similarUrl])
            ->andFilterWhere(['like', 'zhikuTrends', $this->zhikuTrends])
            ->andFilterWhere(['like', 'topicType', $this->topicType])
            ->andFilterWhere(['like', 'industryType', $this->industryType]);
//        $dataProvider->sort->defaultOrder=[
//            'newsId'=>SORT_DESC,
//        ];
        $dataProvider->getPagination()->pageSize=50;
        return $dataProvider;


    }


}
