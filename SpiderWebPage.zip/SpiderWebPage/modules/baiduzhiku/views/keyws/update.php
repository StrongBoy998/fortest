<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Keyws */

$this->title = '爬虫关键词管理';
$this->params['breadcrumbs'][] = '爬虫关键词管理';
?>
<div class="keyws-update">


    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
    <p>关键词之间用中文(全角)逗号隔开</p>
    <p>关键词用英文(半角)双引号包括</p>
</div>
