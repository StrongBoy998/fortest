<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Keyws */

$this->title = '爬虫关键词管理';
$this->params['breadcrumbs'][] = '爬虫关键词管理';
?>
<div class="keyws-view">


    <p>
        <?= Html::a('更新成功', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>

    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'keysName:ntext',
        ],
    ]) ?>

</div>
