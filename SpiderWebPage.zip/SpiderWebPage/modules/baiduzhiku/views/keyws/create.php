<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Keyws */

$this->title = 'Create Keyws';
$this->params['breadcrumbs'][] = ['label' => 'Keyws', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="keyws-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
