<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\modules\baiduzhiku\models\KeywordsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Keywords';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="keywords-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Keywords', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'determine',
            'industryType',
            'zhikuTrends',
             'economic',
             'administrative',
             'partybuilding',
             'anticorruption',
             'politics',
             'culture',
             'diplomacy',
             'military',
             'peoplelivelihood',
             'environmentalprotection',
             'medicaltreatment',
             'education',
             'agriculture',
             'technology',
             'judicature',
             'energy',
             'antiterrorist',
             'policysuggestion',
             'policyanalyzing',
             'expertremarks',
             'internationalcommentary',
             'signedarticles',
             'seminar',
             'lecturesexchange',
             'internationalconference',
             'resultsreleased',
             'leadingvisit',
             'internationalvisit',
             'instruction',
             'researchguidance',
             'foreignmediaattention',
             'projectcooperation',
             'globalcooperation',
             'thinktankconstruction',
             'winningtrends',
             'researchdynamics',
             'personnelchange',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
