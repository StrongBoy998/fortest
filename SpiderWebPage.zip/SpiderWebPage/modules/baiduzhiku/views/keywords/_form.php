<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Keywords */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="keywords-form">

    <?php $form = ActiveForm::begin(); ?>


    <?= $form->field($model, 'determine')->textarea(['rows'=>'5']);  ?>

    <?= $form->field($model, 'industryType')->textarea(['rows'=>'3']);  ?>


    <?= $form->field($model, 'zhikuTrends')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'economic')->textarea(['rows'=>'8']);  ?>

    <?= $form->field($model, 'administrative')->textarea(['rows'=>'8']); ?>

    <?= $form->field($model, 'partybuilding')->textarea(['rows'=>'3']); ?>

    <?= $form->field($model, 'anticorruption')->textarea(['rows'=>'5']);  ?>

    <?= $form->field($model, 'politics')->textarea(['rows'=>'5']);  ?>

    <?= $form->field($model, 'culture')->textarea(['rows'=>'5']);  ?>

    <?= $form->field($model, 'diplomacy')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'military')->textarea(['rows'=>'3']); ?>

    <?= $form->field($model, 'peoplelivelihood')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'environmentalprotection')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'medicaltreatment')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'education')->textarea(['rows'=>'3']); ?>

    <?= $form->field($model, 'agriculture')->textarea(['rows'=>'3']); ?>

    <?= $form->field($model, 'technology')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'judicature')->textarea(['rows'=>'3']);  ?>

    <?= $form->field($model, 'energy')->textarea(['rows'=>'3']); ?>

    <?= $form->field($model, 'antiterrorist')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'policysuggestion')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'policyanalyzing')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'expertremarks')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'internationalcommentary')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'signedarticles')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'seminar')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'lecturesexchange')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'internationalconference')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'resultsreleased')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'leadingvisit')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'internationalvisit')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'instruction')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'researchguidance')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'foreignmediaattention')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'projectcooperation')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'globalcooperation')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'thinktankconstruction')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'winningtrends')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'researchdynamics')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'personnelchange')->textInput(['maxlength' => true]) ?>


    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : '更新', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
