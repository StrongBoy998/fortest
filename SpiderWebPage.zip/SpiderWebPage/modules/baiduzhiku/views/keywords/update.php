<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Keywords */

$this->title = '过滤词+研判词管理';
$this->params['breadcrumbs'][] = '过滤词+研判词管理';
?>
<div class="keywords-update">


    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
<p>关键词之间用中文(全角)逗号隔开</p>
</div>
