<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Keywords */

$this->title = '过滤词+研判词管理';
$this->params['breadcrumbs'][] = '过滤词+研判词管理';
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="keywords-view">


    <p>
        <?= Html::a('更新成功', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>

    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'determine',
            'industryType',
            'zhikuTrends',
            'economic',
            'administrative',
            'partybuilding',
            'anticorruption',
            'politics',
            'culture',
            'diplomacy',
            'military',
            'peoplelivelihood',
            'environmentalprotection',
            'medicaltreatment',
            'education',
            'agriculture',
            'technology',
            'judicature',
            'energy',
            'antiterrorist',
            'policysuggestion',
            'policyanalyzing',
            'expertremarks',
            'internationalcommentary',
            'signedarticles',
            'seminar',
            'lecturesexchange',
            'internationalconference',
            'resultsreleased',
            'leadingvisit',
            'internationalvisit',
            'instruction',
            'researchguidance',
            'foreignmediaattention',
            'projectcooperation',
            'globalcooperation',
            'thinktankconstruction',
            'winningtrends',
            'researchdynamics',
            'personnelchange',
        ],
    ]) ?>

</div>
