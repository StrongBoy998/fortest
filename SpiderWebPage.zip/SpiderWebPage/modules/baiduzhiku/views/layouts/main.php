<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\helpers\Url;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' => '首页智库',
        'brandUrl' => Yii::$app->urlManager->createUrl('/baiduzhiku/crawl-news'),
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [

            [
                'label' => '智库管理配置',
                'url' => ['url0'],
                'options' => ['class' => 'accordion'],
                'items' => [
                    [
                        'label' => '屏蔽词+研判词管理', 'url' =>  Url::toRoute(['/baiduzhiku/keywords/update', 'id' => 1]),
                    ],
                    [
                        'label' => '爬虫关键词管理', 'url' => Url::toRoute(['/baiduzhiku/keyws/update', 'id' => 1]),
                    ],
                ],
            ],
            ['label' => '项目管理', 'url' => ['/baiduzhiku/item/']],
            ['label' => '弃用数据', 'url' => ['/baiduzhiku/crawl-news/determine']],
            ['label' => '研判', 'url' => ['/baiduzhiku/crawl-news/judge']],

            [
                'label' => '统计数据',
                'url' => ['url0'],
                'options' => ['class' => 'accordion'],
                'items' => [
                    [
                        'label' => '统计数据', 'url' =>  ['/baiduzhiku/crawl-news/statistics'],
                    ],
                    [
                        'label' => '生成图表', 'url' =>  ['/baiduzhiku/crawl-news/generatechart'],
                    ],
                    [
                        'label' => '自定义查看数据', 'url' =>  ['/baiduzhiku/crawl-news/choose'],
                    ],
                ],
            ],

//            ['label' => '统计数据', 'url' => ['/baiduzhiku/crawl-news/statistics']],
            ['label' => '导出数据', 'url' => ['/baiduzhiku/crawl-news/export']],


        ],

    ]);
    NavBar::end();

    ?>

    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= $content ?>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <p class="pull-left">&copy; 首页大数据 <?= date('Y') ?></p>


    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
