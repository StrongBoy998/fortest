<?php
use kartik\date\DatePicker;
$this->title = '首页智库';
$this->params['breadcrumbs'][] = '统计数据';
?>

<form action="" method="post">
<?php
echo DatePicker::widget([
    'name' => 'date[]',
    'value' => '',
    'type' => DatePicker::TYPE_RANGE,
    'name2' => 'date[]',
    'value2' => '',
    'options' => ['placeholder' => '开始日期'],
    'options2' => ['placeholder' => '结束日期'],
    'pluginOptions' => [
        'autoclose' => true,
        'format' => 'yyyy-mm-dd',
        'todayHighlight' => true
    ],
    'language'=>'zh-CN',
]);
?>


    <br/>
 <input name="_csrf" type="hidden" id="_csrf" value="<?= Yii::$app->request->csrfToken ?>">
<input type="button"  id="sub" class='btn btn-success' value="确定">
</form>
<br/><br/>



<table id="tabData"  class="table" style="display: none;">
    <tr>
        <th>序列号</th>
        <th>所属智库</th>
        <th>统计</th>
        <th>行业分类</th>
        <th>统计</th>
        <th>智库动态</th>
        <th>统计</th>
        <th>话题分类</th>
        <th>统计</th>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <th>合计</th>
        <th></th>
        <th id="zhikuname"></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>

    </tr>

</table>
</body>
</html>

<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.js" type="text/javascript"></script>
<script>
    $("#sub").click(function () {
        $("td").html("");
        var starttime = $('#w0').val();
        var endtime = $('#w0-2').val();
        if(starttime != ""  || endtime != ""){
            $.get("index.php?r=baiduzhiku/crawl-news/col2",{'starttime':starttime,'endtime':endtime},function(data){
                var col2 = JSON.parse(data);
                var i = -1;
                var m = 0;
                var keycol2 = [];
                var keycol3 = [];
                var result = null;
                for(var k  in  col2){
                    result += parseInt(col2[k]);
                    keycol2.push(k);
                    keycol3.push(col2[k]);

                }
                $("#zhikuname").html(result);
                $("table tr").each(function()
                {
                    $(this).find("td").eq(0).html(m++)
                    $(this).find("td").eq(1).html(keycol2[i])
                    $(this).find("td").eq(2).html(keycol3[i])
                    i = i + 1;
                })
            });

            $.get("index.php?r=baiduzhiku/crawl-news/col4",{'starttime':starttime,'endtime':endtime},function(data){
                var col4 = JSON.parse(data);
                var i = -1;
                var keycol4 = [];
                var keycol5 = [];
                 for(var k  in  col4){
                    keycol4.push(k);
                    keycol5.push(col4[k])
                }
                $("table tr").each(function()
                {
                    $(this).find("td").eq(3).html((keycol4[i]=='未研判')?"<span style='color:red'>"+keycol4[i]+"</span>":keycol4[i])
                    $(this).find("td").eq(4).html(keycol5[i])
                    i = i + 1;
                })

            });

            $.get("index.php?r=baiduzhiku/crawl-news/col6",{'starttime':starttime,'endtime':endtime},function(data){
                var col6 = JSON.parse(data);
                var i = -1;
                var keycol6 = [];
                var keycol7 = [];
                for(var k  in  col6){
                    keycol6.push(k);
                    keycol7.push(col6[k])
                }
                $("table tr").each(function()
                {
                    $(this).find("td").eq(5).html((keycol6[i]=='未研判')?"<span style='color:red'>"+keycol6[i]+"</span>":keycol6[i])
                    $(this).find("td").eq(6).html(keycol7[i])
                    i = i + 1;
                })
            });

            $.get("index.php?r=baiduzhiku/crawl-news/col8",{'starttime':starttime,'endtime':endtime},function(data){
                var col8 = JSON.parse(data);
                var i = -1;
                var keycol8 = [];
                var keycol9 = [];
                for(var k  in  col8){
                    keycol8.push(k);
                    keycol9.push(col8[k])
                }
                $("table tr").each(function()
                {
                    $(this).find("td").eq(7).html((keycol8[i]=='未研判')?"<span style='color:red'>"+keycol8[i]+"</span>":keycol8[i])
                    $(this).find("td").eq(8).html(keycol9[i])
                    i = i + 1;
                })
            });
            $("table").show();
        }else{
            alert('请选择时间'); return;
        }
    })
</script>
