<?php
use kartik\date\DatePicker;
$this->title = '首页智库';
$this->params['breadcrumbs'][] = '首页智库导出excel';
?>

<form action="" method="post">
<?php
echo DatePicker::widget([
    'name' => 'date[]',
    'value' => '',
    'type' => DatePicker::TYPE_RANGE,
    'name2' => 'date[]',
    'value2' => '',
    'options' => ['placeholder' => '开始日期'],
    'options2' => ['placeholder' => '结束日期'],
    'pluginOptions' => [
        'autoclose' => true,
        'format' => 'yyyy-mm-dd',
        'todayHighlight' => true
    ],
    'language'=>'zh-CN',
]);
?>

<br/>
 <input name="_csrf" type="hidden" id="_csrf" value="<?= Yii::$app->request->csrfToken ?>">
<input type="submit"  class='btn btn-success' value="导出数据">
</form>