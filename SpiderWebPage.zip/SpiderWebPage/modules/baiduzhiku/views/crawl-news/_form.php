<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\CrawlNews */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="crawl-news-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'zhikuName')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'keyUrl')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'newsTitle')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'newsUrl')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'mediaName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'publicTime')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'abstract')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'newsDetail')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'similarNum')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'similarUrl')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
