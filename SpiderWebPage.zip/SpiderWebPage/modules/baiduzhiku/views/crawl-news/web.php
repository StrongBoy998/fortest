<?php

$params = require(__DIR__ . '/params.php');
$config = [
    'id'         => 'yii2',
    'basePath'   => dirname(__DIR__) . "/..",
    'bootstrap'  => ['log'],
    'language'   => 'zh-CN',
    'timezone'   => 'PRC',
    'modules'    => [
        'admin'           => [
            'class' => 'app\admin\Site',
        ],
        'rbac'            => [
            'class'        => 'mdm\admin\Module',
            'layout'       => '@app/admin/views/layouts/main',
            'defaultRoute' => 'default',
        ],
        'samples'         => [
            'class' => 'app\samples\Module',
        ],
        'fileuploads'     => [
            'class' => 'app\modules\fileuploads\Handle',
        ],
        'sales'           => [//新增销售管理模块
            'class' => 'app\modules\sales\Sales',
        ],
        'affiche'         => [
            'class' => 'app\modules\affiche\Affiche',
        ],
        'reportstatement' => [
            // 2016年04月19日15:35:20,新增报告汇总模块 —— by 赵振棠
            'class' => 'app\modules\reportstatement\ReportStatement',
        ],
        'questionnaire'   => [
            // 2016年04月29日15:16:19,新增调查问卷模块 —— by 赵振棠
            'class' => 'app\modules\questionnaire\Questionnaire',
        ],
        'report'          => [
            'class' => 'app\modules\report\Report',
        ],
        'cs'              => [
            'class' => 'app\modules\cs\CS',
        ],
        'clientversion'   => [
            'class' => 'app\modules\clientversion\ClientVersion',
        ],
        'front4gov'       => [
            'class' => 'app\modules\front4gov\Front',
        ],
        'msn'             => [
            'class' => 'app\modules\msn\Site',
        ],
        'gt_push'         => [
            // 2016年06月09日19:34:41,新增gt_push模块,集成JPush,用来向手机端推送消息
            'class' => 'app\modules\gt_push\GT_Push',
        ],
        'dantaedata'      => [
            // 2016年08月08日17:00:53,通过gii生成的蛋挞电商数据平台模块 —— by 赵振棠
            'class' => 'app\modules\dantaedata\DantaEData',
        ],
        'wdreport'        => [
            // 2016年08月12日09:32:13,将王老板完成的万达报告模块也添加进来
            'class' => 'app\modules\wdreport\WDReport',
        ],
        'danta'           => [
            // 2016年08月15日10:15:38,添加蛋挞舆情前台 —— by 赵振棠
            'class' => 'app\modules\danta\Danta',
        ],
		'checool_dealer' => [
			'class' => 'app\modules\checool_dealer\checoolDealer'
		]
    ],
    'components' => [
        'request'             => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'JlZrlXMNR0xNTv7GDD-wuWLvl810jZwB',
        ],
        'i18n'                => [
            'translations' => [
                'admin*' => [
                    'class'    => \yii\i18n\PhpMessageSource::className(),
                    'basePath' => '@app/admin/messages',
                    'fileMap'  => [
                        'admin' => 'admin.php'
                    ]
                ],

            ]
        ],
        // 将之前王老板写的rank接口组件注册进来,直接使用
        'rank'                => [
            'class' => 'app\components\rankapi\RankApi',
        ],
        'cache'               => [
            'class' => 'yii\caching\FileCache',
        ],
        'authManager'         => [
            'class' => 'yii\rbac\DbManager',
        ],
        'urlManager'          => [
            'enablePrettyUrl' => true,
            'showScriptName'  => false,
            'rules'           => [
                ''                              => 'admin/default/index',
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
            ],
        ],
        'user'                => [
            'identityClass'   => 'app\admin\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler'        => [
            'errorAction' => 'site/error',
        ],
        'mailer'              => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
//            'transport' => [
//                  'class' => 'Swift_SmtpTransport',
//                  'host' => 'localhost',
//                  'username' => 'username',
//                  'password' => 'password',
//                  'port' => '587',
//                  'encryption' => 'tls',
//            ],
        ],
        'log'                 => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets'    => [
                [
                    'class'  => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'db'                  => require(__DIR__ . '/db.php'),
        'rank' => require(__DIR__ . '/rank.php'),
        'sales_db'            => [
            'class'    => yii\db\Connection::className(),
            'dsn'      => 'mysql:host=127.0.0.1;dbname=salesdb',
            'username' => 'sales',
            'password' => 'saLeS@291=&',
            'charset'  => 'utf8',
        ],
        'front_db'            => [
            'class'    => 'yii\db\Connection',
            'dsn'      => 'mysql:host=127.0.0.1;dbname=yqfront',//for develop
            'username' => 'root',
            'password' => 'ViVe172301',
            'charset'  => 'utf8',
        ],
        'msn_db'              => [
            'class'    => 'yii\db\Connection',
            'dsn'      => 'mysql:host=127.0.0.1;dbname=microsoftzanadu',//for develop
            'username' => 'root',
            'password' => 'root',
            'charset'  => 'utf8',
        ],
        // 报告汇总系统数据库
        'report_statement_db' => [
            'class'    => 'yii\db\Connection',
            'dsn'      => 'mysql:host=127.0.0.1:3309;dbname=report_sys_db',//
            'username' => 'root',
            'password' => '',
            'charset'  => 'utf8',
        ],
        // 调查问卷数据库
        'questionnaire_db'    => [
            'class'    => 'yii\db\Connection',
            'dsn'      => 'mysql:host=127.0.0.1:3309;dbname=questionnaire',//
            'username' => 'root',
            'password' => '',
            'charset'  => 'utf8',
        ],
        // 蛋挞电商数据平台数据库
        'dantaedata_db'       => [
            'class'    => 'yii\db\Connection',
            'dsn'      => 'mysql:host=192.168.169.6:3307;dbname=ebiz',//
            'username' => 'ebiz',
            'password' => 'ebiz',
            'charset'  => 'utf8',
        ],
		//汽车经销商数据库
		'checool_dealer_db'       => [
            'class'    => 'yii\db\Connection',
            'dsn'      => 'mysql:host=127.0.0.1:3309;dbname=checool_dealer',//
            'username' => 'root',
            'password' => '',
            'charset'  => 'utf8',
        ],
    ],
    'as access'  => [
        'class'        => 'mdm\admin\components\AccessControl',
        'allowActions' => [
            'site/login',
            'site/logout',
            'api/*',
            'affiche/default/*',
            'report/default/*',
            'clientversion/default/version',
            // 面向微信用户的调查问卷
            'questionnaire/questionnaire/fillin-questionnaire',
            'questionnaire/questionnaire/add',
            // 蛋挞工商大数据平台登陆Action,以及由于改用舆情系统的登录体系需要额外的开放权限
            'danta/default/*',
            'danta/api/*',
            // 验证码
            'site/captcha',
        ]
    ],
    'params'     => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = 'yii\debug\Module';

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = 'yii\gii\Module';
}

return $config;
