<?php

use yii\helpers\Html;
use yii\grid\GridView;
/* @var $this yii\web\View */
/* @var $searchModel app\models\CrawlNewsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '首页智库';
$this->params['breadcrumbs'][] = '首页智库';
?>
<div class="crawl-news-index">

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'pager'=>[
            'firstPageLabel'=>"第1页",
            'prevPageLabel'=>'上一页',
            'nextPageLabel'=>'下一页',
            'lastPageLabel'=>'末页',
        ],
        'columns' => [
            'newsId',
            ['attribute' => 'zhikuName',
                'value' => 'zhikuName',
                'filter' =>\app\modules\baiduzhiku\models\CrawlNews::getZkname(),
            ],

            [
                'attribute' => 'newsTitle',
                'value' => 'newsTitle',
                'headerOptions' => ['width' => '200px'],
            ],

            [
                'attribute' => 'newsUrl',
                'value' => function ($model) {
                    return Html::a('<span class ="glyphicon glyphicon-link"></span>', "{$model->newsUrl}", ['target' => '_blank']);
                },
                'format' => 'raw',
            ],
             'mediaName',

            [
                'attribute' => 'publicTime',
                'value' => 'publicTime',
                'headerOptions' => ['width' => '180px'],
                'filter' => \app\modules\baiduzhiku\models\CrawlNews::gettime(),
            ],

            [
                'attribute' => 'abstract',
                'value' => 'abstract',
                'headerOptions' => ['width' => '500px'],
            ],

            [
                'attribute' => 'similarNum',
                'value' => function ($model) {
                    return $model->similarNum? Html::a('<span class ="glyphicon glyphicon-info-sign" style="margin-left: 20px">'.$model->similarNum.'</span>', "{$model->similarUrl}", ['target' => '_blank']):'';
                },
                'format' => 'raw',
            ],
            [
                'attribute' => 'status',
                'value' => function($model){
                    return $model->status?'有效':'无效';
                },
                //搜索的规则
                'filter' => ['0'=>'无效','1'=>'有效'],
                'contentOptions'=>
                    function($model){
                        return ($model->status==0)?['class'=>'bg-danger','id'=>'Nid'.$model->newsId,"onclick"=>"approve($model->newsId);"]:
                            ['class'=>'bg-primary','id'=>'Nid'.$model->newsId,"onclick"=>"unapprove($model->newsId);"];
                    }
            ],

        ],
    ]); ?>
</div>

<script>
    function approve(id){
        $.get("index.php?r=baiduzhiku/crawl-news/approve",{id:id},function(data){
           if(data==1){
               $("#Nid"+id).removeClass().addClass("bg-primary");
               $("#Nid"+id).attr("onclick","unapprove("+id+");");
               $("#Nid"+id).html('有效');

           }
        });
    }
    function unapprove(id){
        $.get("index.php?r=baiduzhiku/crawl-news/unapprove",{id:id},function(data){
            if(data==1){
                $("#Nid"+id).removeClass().addClass("bg-danger");
                $("#Nid"+id).attr("onclick","approve("+id+");");
                $("#Nid"+id).html('无效');
            }
        });
    }
</script>
