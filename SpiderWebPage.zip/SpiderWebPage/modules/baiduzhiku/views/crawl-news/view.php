<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\CrawlNews */

$this->title = $model->newsId;
$this->params['breadcrumbs'][] = ['label' => 'Crawl News', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="crawl-news-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->newsId], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->newsId], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'newsId',
            'zhikuName:ntext',
            'keyUrl:ntext',
            'newsTitle:ntext',
            'newsUrl:ntext',
            'mediaName',
            'publicTime',
            'abstract:ntext',
            'newsDetail:ntext',
            'similarNum',
            'similarUrl:ntext',
        ],
    ]) ?>

</div>
