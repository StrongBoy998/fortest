<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\date\DatePicker;
use yii\helpers\Url;


/* @var $this yii\web\View */
/* @var $searchModel app\modules\baiduzhiku\models\ItemSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '项目管理';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="item-index">

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('新增项目', '#', ['class' => 'btn btn-success', 'data-toggle' => 'modal', 'data-target' => '#create-modal',]) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
//        'filterModel' => $searchModel,
        'columns' => [
            'id',
            [
                'attribute' => 'itemname',
                'value' => function ($model) {
                    return  '<a href="'.  Url::to(['item/view','id'=>$model->id]).'">'.$model->itemname.'</a>';
                },
                'format' => 'raw',
            ],
            'starttime',
            'endtime',
            [
                'attribute' => 'status',
                'value' => function ($model) {
                    if ($model->status == 0) {
                        return '<div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="60"
                                     aria-valuemin="0" aria-valuemax="100" style="width: 43%;">爬取中
                                </div></div>';
                    } elseif ($model->status == 1) {
                        return '<div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="60"
                                     aria-valuemin="0" aria-valuemax="100" style="width: 70%;">研判中
                                </div></div>';
                    } else {
                        return '<div class="progress">
                                 <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60"
                                     aria-valuemin="0" aria-valuemax="100" style="width: 100%;"><a href="'.Url::to(['item/generatechart','itemid'=>$model->id]).'">研判完成</a>
                                </div></div>';
                    }
                },
                'format' => 'raw',
            ],
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>

<div class="modal fade" id="create-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
     data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true" id="btnCancel">
                    ×
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    新增项目
                </h4>
            </div>
            <div class="modal-body">
                <div>
                    <table width="100%" border="0" class="userCon_2">

                        <tr>
                            <th>项目名</th>
                            <td>
                                <input type="text" value="" name="itemname" id="itemname">
                            </td>
                        </tr>
                        <tr>
                            <td> &nbsp;</td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>项目时间</th>
                            <td>
                                <?php echo DatePicker::widget([
                                    'name' => 'Item[starttime]',
                                    'value' => '',
                                    'id' => 'time',
                                    'type' => DatePicker::TYPE_RANGE,
                                    'name2' => 'Item[endtime]',
                                    'value2' => '',
                                    'options' => ['placeholder' => '开始日期'],
                                    'options2' => ['placeholder' => '结束日期'],
                                    'pluginOptions' => [
                                        'autoclose' => true,
                                        'format' => 'yyyy-mm-dd',
                                        'todayHighlight' => true
                                    ],
                                    'language' => 'zh-CN',
                                ]);
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer" style="border-top:none;">
                <button type="button" class="btn btn-default" data-dismiss="modal" id="btnClose">关闭</button>
                <a href="javascript:location.reload();" class="btn btn-primary" onclick="saveitem()">保存</a>
            </div>
        </div>
    </div>
</div>

<script>
    function saveitem() {
        var itemname = $("#itemname").val()
        var starttime = $("#time").val()
        var endtime = $("#time-2").val()
        if(itemname=="" ||starttime==""||endtime==""){
            alert('项目名或项目时间未填写')
            return;
        }
        $.get("index.php?r=baiduzhiku/item/createitem", {
            "itemname": itemname,
            "starttime": starttime,
            "endtime": endtime
        }, function (data) {
            if(data=='2'){
                alert('项目名或项目时间未填写')
            }
        })
    }
</script>