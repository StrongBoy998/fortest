<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Item */

$this->title = '新增项目';
$this->params['breadcrumbs'][] = ['label' => '项目管理', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="item-create">


    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
