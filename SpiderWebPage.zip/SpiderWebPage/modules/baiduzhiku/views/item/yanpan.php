<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\modules\baiduzhiku\models\Keywords;

/* @var $this yii\web\View */
/* @var $searchModel app\models\CrawlNewsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '首页智库';
$this->params['breadcrumbs'][] = '首页智库';

?>
<div class="crawl-news-index">

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
//        "rowOptions" => function($model, $key, $index, $grid) {
//            return ["class" => $index % 2 ==0 ? "active" : "success"];
//        },
        'filterModel' => $searchModel,
        'pager' => [
            'firstPageLabel' => "第1页",
            'prevPageLabel' => '上一页',
            'nextPageLabel' => '下一页',
//            'lastPageLabel' => '末页',
        ],
        'columns' => [
            'newsId',
            ['attribute' => 'zhikuName',
                'value' => 'zhikuName',
                'filter' => \app\modules\baiduzhiku\models\CrawlNews::getZkname(),
            ],

            [
                'attribute' => 'newsTitle',
                'value' => 'newsTitle',
                'headerOptions' => ['width' => '200px'],
            ],

            [
                'attribute' => 'newsUrl',
                'value' => function ($model) {
                    return Html::a('<span class ="glyphicon glyphicon-link"></span>', "{$model->newsUrl}", ['target' => '_blank']);
                },
                'format' => 'raw',
            ],
            'mediaName',

            [
                'attribute' => 'publicTime',
                'value' => 'publicTime',
                'headerOptions' => ['width' => '180px'],
                'filter' => \app\modules\baiduzhiku\models\CrawlNews::gettime(),
            ],

            [
                'attribute' => 'abstract',
                'value' => 'abstract',
                'headerOptions' => ['width' => '500px'],
            ],

            [
                'attribute' => 'industryType',
                'value' => function ($model) {
                    $arr = [];
                    foreach (Keywords::getdata()[3] as $v) {
                        $arr[$v] = $v;
                    }
                    if (empty($model->industryType)) {
                        Array_push($arr, '');
                        $html = Html::dropDownList('industryType', 0, $arr, ['onchange' => "itype(this.options[this.options.selectedIndex].value,$model->newsId)"]);
                        $html .= "</br></br><input class='btn btn-defalut' id='itype{$model->newsId}'  type='submit' value='未研判' disabled='disabled' />";
                    } else {
                        $html = Html::dropDownList('industryType', array_search($model->industryType, $arr), $arr, ['onchange' => "itype(this.options[this.options.selectedIndex].value,$model->newsId)"]);
                        $html .= "</br></br><input class='btn btn-success ' id='itype{$model->newsId}'  type='submit' value='已研判' disabled='disabled'  />";
                    }
                    return $html;
                },
                "format" => "raw",
            ],


            [
                'attribute' => 'zhikuTrends',
                'value' => function ($model) {
                    $arr = [];
                    foreach (Keywords::getdata()[1] as $v) {
                        $arr[$v] = $v;
                    }
                    if (empty($model->zhikuTrends)) {
                        Array_push($arr, '');
                        $html = Html::dropDownList('zhikuTrends', 0, $arr, ['onchange' => "ztrends(this.options[this.options.selectedIndex].value,$model->newsId)"]);
                        $html .= "</br></br><input class='btn btn-defalut' id='ztrends{$model->newsId}'  type='submit' value='未研判' disabled='disabled' />";
                    } else {
                        $html = Html::dropDownList('zhikuTrends', array_search($model->zhikuTrends, $arr), $arr, ['onchange' => "ztrends(this.options[this.options.selectedIndex].value,$model->newsId)"]);

                        $html .= "</br></br><input class='btn btn-success ' id='ztrends{$model->newsId}' type='submit' value='已研判' disabled='disabled' />";
                    }
                    return $html;

                },
                "format" => "raw",
            ],

            [
                'attribute' => 'topicType',
                'value' => function ($model) {
                    $html = Html::input('text', 'username', $model->topicType, ['id' => 'ttypeinfo' . $model->newsId]);
                    if (empty($model->topicType)) {
                        $html .= "</br></br><input class='btn btn-defalut' id='ttype{$model->newsId}' onclick='changettype({$model->newsId})' type='submit' value='添加'/>";
                    } else {
                        $html .= "</br></br><input  class='btn btn-success' id='ttype{$model->newsId}' onclick='changettype({$model->newsId})' type='submit' value='修改'/>";
                    }
                    return $html;
                },
                "format" => "raw",
                'headerOptions' => ['width' => '250px'],
            ],


            [
                'attribute' => 'status',
                'value' => function ($model) {
                    return $model->status ? '有效' : '无效';
                },
                //搜索的规则
                'filter' => ['0' => '无效', '1' => '有效'],
                'contentOptions' =>
                    function ($model) {
                        return ($model->status == 0) ? ['class' => 'bg-danger', 'id' => 'Nid' . $model->newsId, "onclick" => "approve($model->newsId);"] :
                            ['class' => 'bg-primary', 'id' => 'Nid' . $model->newsId, "onclick" => "unapprove($model->newsId);"];
                    }
            ],
        ],
    ]); ?>
</div>

<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.js" type="text/javascript"></script>

<script>
    var url = window.location.href;  //取得Get参数
    var itemnum= parseInt(url.substr(pos=url.indexOf("id=")+3,3));//获取项目的编号
    $(".pagination li").click(function () {
        var page = $(this).find("a").text()
        if (!isNaN(page)) {

        } else {
            if (page == "上一页") {
                $(".pagination li").each(function () {
                    if ($(this).hasClass("active")) {
                        page = parseInt($(this).find("a").text()) - 1;
                    }
                })
            } else if ((page == "第1页")) {
                page = 1;
            } else if (page == "下一页") {
                $(".pagination li").each(function () {
                    if ($(this).hasClass("active")) {
                        page = parseInt($(this).find("a").text()) + 1;
                    }
                })
            }
        }
        $.get("index.php?r=baiduzhiku/item/savepage", {"itemnum": itemnum, 'page': page}, function (data) {
            $('html, body').animate({scrollTop:0}, 'slow');
            location.reload()
        })

    })
</script>
<script>
    function itype(info, id) {
        $.get("index.php?r=baiduzhiku/crawl-news/changeitype", {id: id, info: info}, function (data) {
            if (data == 1) {
                $("#itype" + id).removeClass().addClass("btn btn-success");
                if ($("#itype" + id).val() == '已研判') {
                    $("#itype" + id).val('已修改');
                } else {
                    $("#itype" + id).val('已研判');
                }
            }
        });
    }

    function ztrends(info, id) {
        $.get("index.php?r=baiduzhiku/crawl-news/changeztrends", {id: id, info: info}, function (data) {
            if (data == 1) {

                $("#ztrends" + id).removeClass().addClass("btn btn-success");
                if ($("#ztrends" + id).val() == '已研判') {
                    $("#ztrends" + id).val('已修改');
                } else {
                    $("#ztrends" + id).val('已研判');
                }
            }
        });
    }

    function changettype(id) {
        var ttypeinfo = $('#ttypeinfo' + id).val();
        $.get("index.php?r=baiduzhiku/crawl-news/changettype", {id: id, info: ttypeinfo}, function (data) {
            if (data == 1) {
                $("#ttype" + id).removeClass().addClass("btn btn-success");
                if ($("#ttype" + id).val() == '修改') {
                    $("#ttype" + id).val('已修改');
                } else {
                    $("#ttype" + id).val('修改');
                }

            }
        });
    }

    function approve(id) {
        $.get("index.php?r=baiduzhiku/crawl-news/approve", {id: id}, function (data) {
            if (data == 1) {
                $("#Nid" + id).removeClass().addClass("bg-primary");
                $("#Nid" + id).attr("onclick", "unapprove(" + id + ");");
                $("#Nid" + id).html('有效');

            }
        });
    }
    function unapprove(id) {
        $.get("index.php?r=baiduzhiku/crawl-news/unapprove", {id: id}, function (data) {
            if (data == 1) {
                $("#Nid" + id).removeClass().addClass("bg-danger");
                $("#Nid" + id).attr("onclick", "approve(" + id + ");");
                $("#Nid" + id).html('无效');
            }
        });
    }
</script>

