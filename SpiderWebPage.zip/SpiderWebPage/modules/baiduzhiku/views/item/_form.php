<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;


/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Item */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="item-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'itemname')->textInput(['maxlength' => true]) ?>

    <?php
    echo DatePicker::widget([
        'name' => 'Item[starttime]',
        'value' => '',
        'type' => DatePicker::TYPE_RANGE,
        'name2' => 'Item[endtime]',
        'value2' => '',
        'options' => ['placeholder' => $model->starttime?$model->starttime:'开始日期'],
        'options2' => ['placeholder' => $model->endtime?$model->endtime:'结束日期'],
        'pluginOptions' => [
            'autoclose' => true,
            'format' => 'yyyy-mm-dd',
            'todayHighlight' => true
        ],
        'language'=>'zh-CN',
    ]);
    ?>
    </br>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? '新增项目' : '更新项目', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
