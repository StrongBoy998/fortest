<?php
use kartik\date\DatePicker;
use yii\helpers\Html;
use app\modules\baiduzhiku\models\CrawlNews;
$this->title = '首页智库';
$this->params['breadcrumbs'][] = '生成图表';
?>
<?php
$model = new CrawlNews();
$zhikuselect = $model->getZkname();
?>
<form action="" method="post">

    <?= '<table class="table table-bordered">
          <tr>
          <th>项目编号</th>
          <th>项目名</th>
          <th>起始时间</th>
          <th>结束时间</th>
          </tr> 
          <tr>
          <td>' . $datas->id . '</td>
          <td>' . $datas->itemname . '</td>
          <td id="starttime">' . $datas->starttime . '</td>
          <td id="endtime">' . $datas->endtime . '</td>
          </tr>
         </table>';
    ?>
    </br>
    <label for="exampleInputName2">智库名</label>
    <?= Html::dropDownList('username', null, $zhikuselect, ['id'=>'zhikuselect','class' => 'form-control','style'=>'width:200px']); ?>
    <br/>
    <input name="_csrf" type="hidden" id="_csrf" value="<?= Yii::$app->request->csrfToken ?>">
    <input type="button"  id="sub" class='btn btn-success' value="确定">
</form>
<br/><br/>

<div id="main" style="width: 900px;height:700px;display: none;" ></div>

</body>
</html>

<script src="http://apps.bdimg.com/libs/jquery/2.1.4/jquery.js" type="text/javascript"></script>
<script type="text/javascript" src="./statics/js/echarts.js" charset="utf-8"></script>



<script>
    $("#sub").click(function () {
        var starttime = $('#starttime').text();
        var endtime = $('#endtime').text();
        var zhikuselect = $('#zhikuselect').val();
        $.get("index.php?r=baiduzhiku/crawl-news/chartinter",{'starttime':starttime,'endtime':endtime,'zhikuselect':zhikuselect},function(data){
//            console.log(data);return;
            var industryTypedatas = JSON.parse(data)[0];
            var zhikuTrendsdatas = JSON.parse(data)[1];
            var topicTypedatas = JSON.parse(data)[2];
            var  iType = [];
            for(k in industryTypedatas){
                iType.push({value:industryTypedatas[k],name:k})
            }

            var  Trends = [];
            for(k in zhikuTrendsdatas){
                Trends.push({value:zhikuTrendsdatas[k],name:k})
            }

            var  tType = [];
            for(k in topicTypedatas){
                tType.push({value:topicTypedatas[k],name:k})
            }


            var myChart = echarts.init(document.getElementById('main'));
            option = {
                title: {
                    text: zhikuselect+" 工作动态分析",
                    subtext: starttime +'  至  '+endtime,
                    left: 'center'
                },
                tooltip: {
                    trigger: 'item',
                    formatter: "{a} <br/>{b}: {c} ({d}%)"
                },

                toolbox: {
                    show: true,
                    feature: {
                        saveAsImage: {}
                    }
                },
                series: [
                    {
                        name:'工作动态',
                        type:'pie',
                        selectedMode: 'single',

                        radius: [0, '15%'],
                        center: ['45%', '50%'],
                        data:Trends
                    },
                    {
                        name: '行业分类',
                        type: 'pie',
                        selectedMode: 'single',
                        radius: ['48%', '65%'],
//                        left: '70%',
                            center: ['45%', '50%'],
                        data:iType
                    },
                    {
                        tooltip: {
                            trigger: 'item',
                            formatter: "{a} <br/>{b} : {c}" + "",
                        },
                        name: '话题分类',
                        type: 'funnel',
                        width: '20%',
                        height: '30%',
                        left: '70%',
                        top: '5%',
                        data:tType
                    },
                ]
            };
            myChart.setOption(option);
            $("#main").show();
        })
    })
</script>



