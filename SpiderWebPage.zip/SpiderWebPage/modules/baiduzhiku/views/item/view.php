<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\modules\baiduzhiku\models\Item */

$this->params['breadcrumbs'][] = ['label' => '项目管理', 'url' => ['index']];
$this->params['breadcrumbs'][] = '查看项目';
?>
<div class="item-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('更新项目', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('删除项目', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'itemname',
            'starttime',
            'endtime',
            [
                'attribute' => 'status',
                'value' => function($model){
                    if($model->status==0){
                        return '正在爬取中';
                    }elseif ($model->status==1){
                        return '研判中';
                    }else{
                        return '研判完成';
                    }
                },
]
        ],
    ]) ?>

</div>
