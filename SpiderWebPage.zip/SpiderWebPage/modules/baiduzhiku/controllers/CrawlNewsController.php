<?php

namespace app\modules\baiduzhiku\controllers;
use Yii;
use app\modules\baiduzhiku\models\CrawlNews;
use app\modules\baiduzhiku\models\Keywords;
use app\modules\baiduzhiku\models\CrawlNewsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use PHPExcel;
use yii\helpers\Html;


/**
 * CrawlNewsController implements the CRUD actions for CrawlNews model.
 */
class CrawlNewsController extends Controller
{
    public $layout = "main";
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionChoose(){
            if (!Yii::$app->request->isPost) {
                $unitname = CrawlNews::getZkname();
                return $this->render('choose',['unitname'=>$unitname]);
            }else{
                if(empty($_POST['date'][0])||empty($_POST['date'][1])){
                    return  "请选择时间";
                }
                if(empty($_POST['hid'])){
                    return "请选择发布单位";
                }
                $this->redirect(array('showdata','id'=>$_POST));
            }
    }

    public function actionShowdata()
    {

        $searchModel = new CrawlNewsSearch();
        $dataProvider = $searchModel->searchcho(Yii::$app->request->queryParams);
        return $this->render('index2', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }


    //研判
    public function actionJudge(){

        $searchModel = new CrawlNewsSearch();
        $dataProvider = $searchModel->search2(Yii::$app->request->queryParams);
        return $this->render('index2', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'keywords'=>Keywords::getdata(),
        ]);
    }




    //过滤
    public function actionDetermine(){
        $searchModel = new CrawlNewsSearch();
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
        return $this->render('index1', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);

    }

    /**
     * Lists all CrawlNews models.
     * @return mixed
     */
    public function actionIndex()
    {
//         return  print_r(Keywords::getdata());
        $searchModel = new CrawlNewsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * 从mysql数据库导出数据
     * @param 起始时间 and  结束时间
     * @return excel文件
     */
    public function actionExport()
    {
        if (!Yii::$app->request->isPost) {
            return $this->render('export');
        } else {
            //设置北京时区
//            ini_set('date.timezone','Asia/Shanghai');
            //设置php超时时间
            ini_set("max_execution_time", "3600");
            ini_set('memory_limit','512M');
            $start = strtotime(Yii::$app->request->post('date')[0]);
            $end   = strtotime(Yii::$app->request->post('date')[1]);

            $objectPHPExcel = new PHPExcel();
            $objectPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', '标题')
                ->setCellValue('B1', '时间')
                ->setCellValue('C1', '正文')
                ->setCellValue('D1', '来源')
                ->setCellValue('E1', '相关新闻')
                ->setCellValue('F1', '网址')
                ->setCellValue('G1', '智库')
                ->setCellValue('H1', '智库动态')
                ->setCellValue('I1', '话题分类')
                ->setCellValue('J1', '行业分类');
            //从从数据库查出数据
            $datas = CrawlNews::find()->select([
                'newsTitle',
                'publicTime',
                'abstract',
                'mediaName',
                'similarNum',
                'newsUrl',
                'zhikuName',
                'zhikuTrends',
                'topicType',
                'industryType',
            ])->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['status'=>1])->orWhere(['status'=>2])->asArray()->all();
            $i = 2;

            foreach ($datas as $data) {
                if($data['zhikuName']=='中国社科院国家金融与发展实验室'){
                    $data['zhikuName'] = '国家金融与发展实验室';
                }elseif ($data['zhikuName']=='中国社科院国家全球战略智库'){
                    $data['zhikuName'] = '国家全球战略智库';
                }elseif ($data['zhikuName']=='国家发改委宏观经济研究院'){
                    $data['zhikuName'] = '国家发展改革委宏观经济研究院';
                }elseif ($data['zhikuName']=='人大国家发展与战略研究院'){
                    $data['zhikuName'] = '中国人民大学国家发展与战略研究院';
                }
                $objectPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue("A$i", $data['newsTitle'])
                    ->setCellValue("B$i", $data['publicTime'])
                    ->setCellValue("C$i", $data['abstract'])
                    ->setCellValue("D$i", $data['mediaName'])
                    ->setCellValue("E$i", $data['similarNum'])
                    ->setCellValue("F$i", $data['newsUrl'])
                    ->setCellValue("G$i", $data['zhikuName'])
                    ->setCellValue("H$i", $data['zhikuTrends'])
                    ->setCellValue("I$i", $data['topicType'])
                    ->setCellValue("J$i", $data['industryType']);
                $i++;
            }

            //防止乱码
            ob_end_clean();
            ob_start();

            header('Content-Type : application/vnd.ms-excel');
            header('Content-Disposition:attachment;filename="' . '百度智库-' . date("Y年m月d日 H时i分") . '.xls"');
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save('php://output');
        }

    }


    public function actionExportchooseData()
    {

        //设置php超时时间
        ini_set("max_execution_time", "3600");
        ini_set('memory_limit', '512M');
        $start = strtotime(Yii::$app->request->get('starttime'));
        $end = strtotime(Yii::$app->request->get('endtime'));
        $seldata = Yii::$app->request->get('sel');
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', '标题')
            ->setCellValue('B1', '时间')
            ->setCellValue('C1', '正文')
            ->setCellValue('D1', '来源')
            ->setCellValue('E1', '相关新闻')
            ->setCellValue('F1', '网址')
            ->setCellValue('G1', '智库')
            ->setCellValue('H1', '智库动态')
            ->setCellValue('I1', '话题分类')
            ->setCellValue('J1', '行业分类');
        //从从数据库查出数据
        $datas = CrawlNews::find()->select([
            'newsTitle',
            'publicTime',
            'abstract',
            'mediaName',
            'similarNum',
            'newsUrl',
            'zhikuName',
            'zhikuTrends',
            'topicType',
            'industryType',
        ])->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['zhikuName'=>$seldata])->andWhere(['status'=>1])->orWhere(['status'=>2])->asArray()->all();
        $i = 2;

        foreach ($datas as $data) {
            if($data['zhikuName']=='中国社科院国家金融与发展实验室'){
                $data['zhikuName'] = '国家金融与发展实验室';
            }elseif ($data['zhikuName']=='中国社科院国家全球战略智库'){
                $data['zhikuName'] = '国家全球战略智库';
            }elseif ($data['zhikuName']=='国家发改委宏观经济研究院'){
                $data['zhikuName'] = '国家发展改革委宏观经济研究院';
            }elseif ($data['zhikuName']=='人大国家发展与战略研究院'){
                $data['zhikuName'] = '中国人民大学国家发展与战略研究院';
            }
            $objectPHPExcel->setActiveSheetIndex(0)
                ->setCellValue("A$i", $data['newsTitle'])
                ->setCellValue("B$i", $data['publicTime'])
                ->setCellValue("C$i", $data['abstract'])
                ->setCellValue("D$i", $data['mediaName'])
                ->setCellValue("E$i", $data['similarNum'])
                ->setCellValue("F$i", $data['newsUrl'])
                ->setCellValue("G$i", $data['zhikuName'])
                ->setCellValue("H$i", $data['zhikuTrends'])
                ->setCellValue("I$i", $data['topicType'])
                ->setCellValue("J$i", $data['industryType']);
            $i++;
        }


        //防止乱码
        ob_end_clean();
        ob_start();
        header('Content-Type : application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename="' . '部委和国务院直属机构发布政策爬虫-' . date("Y年m月d日", $start) . '-' . date("Y年m月d日", $end) . '.xls"');

        $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
        $objWriter->save('exportData/Zhiku.xls');
        return 1;
    }


    //统计数据
    public function actionStatistics(){
        return $this->render('statistics');
    }

    /**
     * Displays a single CrawlNews model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }


    /**
     * Finds the CrawlNews model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return CrawlNews the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = CrawlNews::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    //设置数据可用状态 调用model 对应方法
    public function actionApprove($id){
        $model=$this->findModel($id);
        if($model->approve()){
            return 1;
        }
    }

    //设置数据不可用状态 调用model 对应方法
    public function actionUnapprove($id){
        $model=$this->findModel($id);
        if($model->unapprove()){
            return 1;
        }
    }

    //设置数据已经可以研判
//    public function actionJudg($id){
//        $model=$this->findModel($id);
//        if($model->judg($_GET['zhikuTrends'],$_GET['topicType'],$_GET['industryType'],$_GET['custom'])){
//            return 1;
//        }
//    }

    //修改行业信息
    public function actionChangeitype($id,$info){

        $model=$this->findModel($id);
        if($model->Changeitype($info)){
            return 1;
        }
    }

    //修改智库动
    public function actionChangeztrends($id,$info){
        $model=$this->findModel($id);
        if($model->Changeztrends($info)){
            return 1;
        }
    }

    //修改智库动
    public function actionChangettype($id,$info){
        $model=$this->findModel($id);
        if($model->Changettype($info)){
            return 1;
        }
    }

    //所属智库
    public function actionCol2(){
        $start = strtotime($_GET['starttime']);
        $end =   strtotime($_GET['endtime']);
        $datas = CrawlNews::find()->select('zhikuName,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['status'=>1])->groupBy(['zhikuName'])->asArray()->all();
        $arr = [];
        foreach ($datas as $data){
            if($data['zhikuName'] == ''){
                $arr["未研判"] = $data['count("newsId")'];
            }else{
                $arr[$data['zhikuName']] = $data['count("newsId")'];
            }
        }
        arsort($arr);
        return json_encode($arr);
    }



    //行业分类
    public function actionCol4(){
        $start = strtotime($_GET['starttime']);
        $end =   strtotime($_GET['endtime']);
        $datas = CrawlNews::find()->select('industryType,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['status'=>1])->groupBy(['industryType'])->asArray()->all();
        $arr = [];
        foreach ($datas as $data){
            if($data['industryType'] == ''){
                $arr["未研判"] = $data['count("newsId")'];
            }else{
                $arr[$data['industryType']] = $data['count("newsId")'];
            }
        }
        arsort($arr);
        return json_encode($arr);
    }



    //智库动态
    public function actionCol6(){
        $start = strtotime($_GET['starttime']);
        $end =   strtotime($_GET['endtime']);
        $datas = CrawlNews::find()->select('zhikuTrends,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['status'=>1])->groupBy(['zhikuTrends'])->asArray()->all();
        $arr = [];
        foreach ($datas as $data){
            if($data['zhikuTrends'] == ''){
                $arr["未研判"] = $data['count("newsId")'];
            }else{
                $arr[$data['zhikuTrends']] = $data['count("newsId")'];
            }
        }
        arsort($arr);
        return json_encode($arr);
    }




    public function actionCol8(){
        $start = strtotime($_GET['starttime']);
        $end =   strtotime($_GET['endtime']);
        $datas = CrawlNews::find()->select('topicType,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['status'=>1])->groupBy(['topicType'])->asArray()->all();
        $arr = [];
        foreach ($datas as $data){
            if($data['topicType'] == ''){
                $arr["未研判"] = $data['count("newsId")'];
            }else{
                $arr[$data['topicType']] = $data['count("newsId")'];
            }
        }
        arsort($arr);
        return json_encode($arr);
    }



    //人生中第一次写接口
    public function actionChartinter(){
        $start = strtotime($_GET['starttime']);
        $end =   strtotime($_GET['endtime']);
        $zhikuName =   $_GET['zhikuselect'];
//        $start = '1490198400';
//        $end = '1490198400';
//        $zhikuName = '新华社';

        //智库动态
        $zhikuTrendsdatas = CrawlNews::find()->select('zhikuTrends,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['zhikuName'=>$zhikuName])->andWhere(['status'=>1])->groupBy('zhikuTrends')->asArray()->all();
        $Trends = [];
        $sum = '';
        foreach ($zhikuTrendsdatas as $data){
               $sum += $data['count("newsId")'];
        }

        foreach ($zhikuTrendsdatas as $data){
            if($data['zhikuTrends'] == ''){
                  $Trends['未研判'.' '.round($data['count("newsId")']/$sum*100,1).'%'] = $data['count("newsId")'];
            }else{
                $Trends[$data['zhikuTrends'].' '.round($data['count("newsId")']/$sum*100,1).'%'] = $data['count("newsId")'];
            }
        }


        //行业分类
        $industryTypedatas = CrawlNews::find()->select('industryType,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['zhikuName'=>$zhikuName])->andWhere(['status'=>1])->groupBy('industryType')->asArray()->all();
        $iType = [];
        $sum = '';
        foreach ($industryTypedatas  as $data){
            $sum += $data['count("newsId")'];
        }

        foreach ($industryTypedatas  as $data){
            if($data['industryType'] == ''){
                $iType['未研判'.' '.round($data['count("newsId")']/$sum*100,1).'%'] = $data['count("newsId")'];
            }else{
                $iType[$data['industryType'].' '.round($data['count("newsId")']/$sum*100,1).'%'] = $data['count("newsId")'];
            }
        }


        //话题分类
        $topicTypedatas = CrawlNews::find()->select('topicType,count("newsId")')->where(['BETWEEN', 'crawlStamp', $start, $end])->andWhere(['zhikuName'=>$zhikuName])->andWhere(['status'=>1])->groupBy('topicType')->asArray()->all();
        $tType = [];
        $sum = '';
        foreach ($topicTypedatas  as $data){
            $sum += $data['count("newsId")'];
        }
        foreach ($topicTypedatas  as $data){
            if($data['topicType'] == ''){
                $tType['未研判'.' '.round($data['count("newsId")']/$sum*100,1).'%'] = $data['count("newsId")'];
            }else{
                $tType[$data['topicType'].' '.round($data['count("newsId")']/$sum*100,1).'%'] = $data['count("newsId")'];
            }
        }

        $data = [array_slice($iType,0,7),array_slice($Trends,0,6),array_slice($tType,0,4)];
//        return $data;
        return json_encode($data);
    }//妈的,这个不是接口啊

    public function actionGeneratechart(){

        return $this->render('generatechart');
    }



}
