<?php

namespace app\modules\baiduzhiku\controllers;

use Yii;
use app\modules\baiduzhiku\models\Keyws;
use app\modules\baiduzhiku\models\KeywsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * KeywsController implements the CRUD actions for Keyws model.
 */
class KeywsController extends Controller
{
    public $layout = "main";
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Keyws models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new KeywsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Keyws model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Keyws model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
//    public function actionCreate()
//    {
//        $model = new Keyws();
//
//        if ($model->load(Yii::$app->request->post()) && $model->save()) {
//            return $this->redirect(['view', 'id' => $model->id]);
//        } else {
//            return $this->render('create', [
//                'model' => $model,
//            ]);
//        }
//    }

    /**
     * Updates an existing Keyws model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post())) {
            //处理传过来的数据 先替换掉用户打错的引号
            //然后用户传过来的前后两个逗号给屏蔽掉
            //然后检测首和尾的字符是不是"  不是就添加一个"
            //然后保存到数据库里面

            $keysName = str_replace('“','"',$_POST['Keyws']['keysName']);
            $keysName = str_replace('”','"',$keysName );
            $keysName = str_replace(',','，',$keysName );
            $keysName = trim($keysName,',');
            $keysName = trim($keysName,'，');
            (substr($keysName, -1) == '"')?"":$keysName = $keysName.'"';
            (substr($keysName, 0,1) == '"')?"":$keysName = '"'.$keysName;
            $model->keysName =  $keysName;
            if($model->save()){
                return $this->redirect(['view', 'id' => $model->id]);
            }else{
                return '修改失败';
            }

        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Keyws model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
//    public function actionDelete($id)
//    {
//        $this->findModel($id)->delete();
//
//        return $this->redirect(['index']);
//    }

    /**
     * Finds the Keyws model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return Keyws the loaded model
     * @throws NotFoun  dHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Keyws::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
