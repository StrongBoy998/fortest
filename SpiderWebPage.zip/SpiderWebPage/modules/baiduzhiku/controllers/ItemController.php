<?php

namespace app\modules\baiduzhiku\controllers;

use app\modules\sales\models\project;
use Yii;
use app\modules\baiduzhiku\models\Item;
use app\modules\baiduzhiku\models\ItemSearch;
use app\modules\baiduzhiku\models\CrawlNews;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use app\modules\baiduzhiku\models\CrawlNewsSearch;
use app\modules\baiduzhiku\models\Keywords;
use yii\filters\VerbFilter;

/**
 * ItemController implements the CRUD actions for Item model.
 */
class ItemController extends Controller
{

    public $layout = "main";
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionGeneratechart(){
        $itmeid = $_GET['itemid'];
        $datas = $this->findModel($itmeid);
        return $this->render('generatechart',[
        'datas' => $datas,
        ]);
    }

    /**
     * Lists all Item models.
     * @return mixed
     */
    public function actionIndex()
    {
        $this->beforindex();
        $searchModel = new ItemSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }


    //在进入项目列表之前判断并改变项目状态
    //0 未爬取完
    //1 没有研判完成
    //2 研判完毕了
    public function beforindex(){
        $alldata = Item::find()->asArray()->all();
        foreach ($alldata as $v ){

            $data = CrawlNews::find()->where(['crawlStamp'=>strtotime($v['endtime'])])->count();
            if(!empty($data)){
                //还未研判的有多少条
                $line = CrawlNews::find()->where(['BETWEEN', 'crawlStamp', strtotime($v['starttime']), strtotime($v['endtime'])])->andWhere('status=1')->andWhere('(zhikuTrends="" or topicType="" or industryType="")')->count();
                if(empty($line)){
                    $model  = $this->findModel($v['id']);
                    $model->status = 2;
                    $model->save();
                }else{
                    $model  = $this->findModel($v['id']);
                    $model->status = 1;
                    $model->save();
                }

            }else{
                $model  = $this->findModel($v['id']);
                $model->status = 0;
                $model->save();
            }
        }



}
    /**
     * Displays a single Item model.
     * @param integer $id
     * @return mixed
     */
    //查看对应日期的项目
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $start =  strtotime($model ->starttime);
        $end =  strtotime($model->endtime);
        $page = $model->page;
        $searchModel = new CrawlNewsSearch();
        $dataProvider = $searchModel->itemdatas(Yii::$app->request->queryParams,$start,$end,$page);
//        return print_r($dataProvider);
        return $this->render('yanpan', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    //记录上次页码数
    public function actionSavepage(){
        $itemnum = $_GET['itemnum'];
        $page = $_GET['page'];
        $model = $this->findModel($itemnum);
        $model->page=$page;
        if($model->save()){
            return 1;
        }
}


    /**
     * Creates a new Item model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Item();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }
    public function actionCreateitem(){
        $model = new Item();
        if($_GET['itemname']=="" || $_GET['starttime']=="" ||$_GET['endtime']==""){
            return 2;
        }
        $model->itemname = $_GET['itemname'];
        $model->starttime = $_GET['starttime'];
        $model->endtime = $_GET['endtime'];

        if($model->save()){
            return 1;
        }
    }

    /**
     * Updates an existing Item model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Item model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Item model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Item the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Item::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
