<?php

namespace app\modules\baiduzhiku\controllers;

use Yii;
use app\modules\baiduzhiku\models\Keywords;
use app\modules\baiduzhiku\models\KeywordsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * KeywordsController implements the CRUD actions for Keywords model.
 */
class KeywordsController extends Controller
{


    public function actionTest(){
        return print_r(Keywords::getdata());
    }



    //按研究提供的关键词研判
    public function actionWordjudge(){


        if($_GET['id']=='16364361'){
        }else{
            exit();
        }
        ini_set('date.timezone','Asia/Shanghai');
        ini_set("max_execution_time", "3600");
        ini_set('memory_limit','512M');
        $beginYesterday=mktime(0,0,0,date('m'),date('d')-1,date('Y'));
        $beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
        $words = Keywords::getdata();
        $keywords = $words[0];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  status = 0  WHERE (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

//        经济
        $keywords = $words[4];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '经济' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //行政
        $keywords = $words[5];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '行政' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //党建
        $keywords = $words[6];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '党建' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //反腐
        $keywords = $words[7];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '反腐' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //政治
        $keywords = $words[8];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '政治' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //文化
        $keywords = $words[9];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '文化' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //外交
        $keywords = $words[10];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '外交' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //军事
        $keywords = $words[11];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '军事' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //民生
        $keywords = $words[12];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '民生' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //环保
        $keywords = $words[13];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '环保' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //医疗
        $keywords = $words[14];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '医疗' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //教育
        $keywords = $words[15];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '教育' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }


        //农业
        $keywords = $words[16];
        foreach ($keywords as $keyword) {
            $sql .= "UPDATE crawlNews SET industryType = '农业' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%" . $keyword . "%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }

        //科技
        $keywords = $words[17];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '科技' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }


        //司法
        $keywords = $words[18];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '司法' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }


        //能源
        $keywords = $words[19];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '能源' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }


        //反恐
        $keywords = $words[20];
        foreach ($keywords as $keyword){
            $sql  .= "UPDATE crawlNews SET industryType = '反恐' WHERE status = 1 AND (`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%')  AND crawlStamp BETWEEN   $beginYesterday AND $beginToday ;";
        }
//        echo $sql;return;
        Yii::$app->db->createCommand(rtrim($sql,';'))->execute();



        //政策建议
        $keywords = $words[21];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '政策建议' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //政策解读
        $keywords = $words[22];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '政策解读' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //专家言论
        $keywords = $words[23];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '专家言论' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //国际时评
        $keywords = $words[24];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '国际时评' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //署名文章
        $keywords = $words[25];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '署名文章' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //座谈会/研讨会
        $keywords = $words[26];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '座谈会/研讨会' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //讲学交流
        $keywords = $words[27];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '讲学交流' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //国际会议发言
        $keywords = $words[28];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '国际会议发言' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //成果发布
        $keywords = $words[29];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '成果发布' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //领导来访
        $keywords = $words[30];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '领导来访' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //国际访问　
        $keywords = $words[31];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '国际访问' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //指示批示
        $keywords = $words[32];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '指示批示' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //调研指导
        $keywords = $words[33];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '调研指导' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //外媒关注
        $keywords = $words[34];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '外媒关注' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //项目合作
        $keywords = $words[35];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '项目合作' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

        //国际合作
        $keywords = $words[36];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '国际合作' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();


        //智库建设
        $keywords = $words[37];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '智库建设' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();


        //获奖动态
        $keywords = $words[38];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '国际合作' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();


        //研究动态
        $keywords = $words[39];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '研究动态' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();


        //人事变动
        $keywords = $words[40];
        $sql = '';
        foreach ($keywords as $keyword){
            $sql .= "`newsTitle` LIKE '%".$keyword."%' OR `abstract` LIKE '%".$keyword."%' OR ";
        }
        $sql = "UPDATE  crawlNews  SET  zhikuTrends = '人事变动' WHERE  status = 1  AND (".rtrim($sql,'OR ').") AND crawlStamp BETWEEN   $beginYesterday AND $beginToday";
        Yii::$app->db->createCommand($sql)->execute();

    }


    public $layout = "main";

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Keywords models.
     * @return mixed
     */
//    public function actionIndex()
//    {
//        $searchModel = new KeywordsSearch();
//        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
//
//        return $this->render('index', [
//            'searchModel' => $searchModel,
//            'dataProvider' => $dataProvider,
//        ]);
//    }

    /**
     * Displays a single Keywords model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Keywords model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
//    public function actionCreate()
//    {
//        $model = new Keywords();
//
//        if ($model->load(Yii::$app->request->post()) && $model->save()) {
//            return $this->redirect(['view', 'id' => $model->id]);
//        } else {
//            return $this->render('create', [
//                'model' => $model,
//            ]);
//        }
//    }

    /**
     * Updates an existing Keywords model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Keywords model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
//    public function actionDelete($id)
//    {
//        $this->findModel($id)->delete();
//
//        return $this->redirect(['index']);
//    }

    /**
     * Finds the Keywords model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Keywords the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Keywords::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
